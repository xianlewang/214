package rec03;

public class TeachingAssistant {

	private String name ;
	private String course ;
	private int hoursGrading ;

	@Override
	public boolean equals(Object obj){
		if (!(obj instanceof TeachingAssistant))
			return false;
		TeachingAssistant t = (TeachingAssistant)obj;
		return name.equals(t.name)&&course.equals(t.course);
	}
	public int hashCode(){
		return name.hashCode();
	}
}
