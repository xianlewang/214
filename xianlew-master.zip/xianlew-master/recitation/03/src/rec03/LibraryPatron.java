package rec03;

public class LibraryPatron {

	private int money;
	public void chargeLateFee ( int lateFeeInCents ){
		System.out.println("Charged: "+lateFeeInCents);
		return;
	}

}
