package rec03;

public interface LibraryItem {
	public int lateFees(int overDue);
	public void checkIn ( LibraryPatron patron ,
			int daysOut ,
			LibraryItem item );


}
