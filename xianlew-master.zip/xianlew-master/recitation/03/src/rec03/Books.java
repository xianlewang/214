package rec03;

public class Books implements LibraryItem{

	private int checkOutPeriod;
	public Books(){
		checkOutPeriod = 7;
	}
	@Override
	public int lateFees(int days) {
		int overdue = days - checkOutPeriod;
		if(overdue<=7){
			return 15*overdue;
		}
		return 15*7+50*(overdue-7);
	}

	@Override
	public void checkIn(LibraryPatron patron, int daysOut, LibraryItem item) {
		int lateFeeInCents  = item.lateFees(daysOut);
		patron.chargeLateFee ( lateFeeInCents );
	}
	
	public static void main(String[] args){
		Books book = new Books();
		LibraryPatron p = new LibraryPatron();
		book.checkIn(p, 15, book);
	}

}
