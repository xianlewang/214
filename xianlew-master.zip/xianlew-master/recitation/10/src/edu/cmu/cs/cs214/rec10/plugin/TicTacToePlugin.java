package edu.cmu.cs.cs214.rec10.plugin;

import edu.cmu.cs.cs214.rec10.framework.core.GameFramework;
import edu.cmu.cs.cs214.rec10.framework.core.GamePlugin;

public class TicTacToePlugin implements GamePlugin {

	@Override
	public String getGameName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getGridWidth() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getGridHeight() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void onRegistered(GameFramework framework) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onNewGame() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onNewMove() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isMoveValid(int x, int y) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isMoveOver() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void onMovePlayed(int x, int y) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isGameOver() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getGameOverMessage() {
		// TODO Auto-generated method stub
		return null;
	}

}
