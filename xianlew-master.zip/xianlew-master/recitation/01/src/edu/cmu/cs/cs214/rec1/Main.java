package edu.cmu.cs.cs214.rec1;

public class Main {
    public static void main(String[] args) {
        Animal wolf = new Animal("Ghost", "Bark bark.");
        Person jon = new Person("Jon Snow");
        //test
        jon.addPet(wolf);
        // jon.speak();
    }
}