package rec07;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class FirstPanel extends JPanel{

	private final JTextField text;
	private final JButton button;
	private final JLabel label;
	private String name;

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public FirstPanel(){
		name = null;
		text = new JTextField(20);
		String buttonStr = "Submit";
		button = new JButton(buttonStr);
		button.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				name = text.getText();
			}
			
		});
		label = new JLabel("Name: ");
		add(label);
		add(text);
		add(button);
	}
	

}
