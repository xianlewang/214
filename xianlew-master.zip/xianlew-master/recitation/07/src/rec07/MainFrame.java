package rec07;

import javax.swing.JFrame;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class MainFrame extends JFrame {
	private final JPanel panel1;
	private final JPanel panel2;
	public MainFrame() {
		panel1 = new FirstPanel();
		panel2 = new SecondPanel();
		add(panel1);
	}

	public static void main(String[] args) {

		JFrame f = new MainFrame();
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.pack();
		f.setResizable(false);
		f.setVisible(true);

	}
}
