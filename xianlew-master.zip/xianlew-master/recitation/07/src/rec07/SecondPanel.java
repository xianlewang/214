package rec07;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class SecondPanel extends JPanel{

	private final JTextField text;
	private final JButton button;
	private final JLabel label;

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public SecondPanel(){
		text = new JTextField(20);
		String buttonStr = "Submit";
		button = new JButton(buttonStr);
		label = new JLabel("Name: ");
		add(label);
		add(text);
		add(button);
	}
	

}