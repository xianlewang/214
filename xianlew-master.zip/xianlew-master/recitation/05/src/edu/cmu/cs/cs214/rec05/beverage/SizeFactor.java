/**
 * rec5 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 30 2013
 */
package edu.cmu.cs.cs214.rec05.beverage;

/**
 * @author xianlewang
 *
 */
public interface SizeFactor {
	public int getCost();
}
