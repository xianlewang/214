/**
 * rec5 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 30 2013
 */
package edu.cmu.cs.cs214.rec05.beverage;

/**
 * @author xianlewang
 *
 */
public final class CoffeeSizeFactor implements SizeFactor{

	private int price;
	public CoffeeSizeFactor(String size){
		switch(size){
		case "small": price = 40;break;
		case "medium": price = 70;break;
		case "large": price = 100;break;
		}
	}
	@Override
	public int getCost() {
		return price;
	}

}
