/**
 * rec5 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 30 2013
 */
package edu.cmu.cs.cs214.rec05.ingredients;

import edu.cmu.cs.cs214.rec05.beverage.Beverage;

/**
 * @author xianlewang
 *
 */
public final class Jasmine extends FlavoredBeverage{
	private int price = 50;
	private Beverage beverage;
	public Jasmine(Beverage beverage ){
		this.beverage = beverage;
		price+=beverage.getCost();
	}
	@Override
	public int getCost(){
		return price;
	}
}
