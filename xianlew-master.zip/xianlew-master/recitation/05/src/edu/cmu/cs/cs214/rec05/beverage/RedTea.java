/**
 * rec5 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 30 2013
 */
package edu.cmu.cs.cs214.rec05.beverage;

/**
 * @author xianlewang
 * 
 */
public final class RedTea extends Tea {
	private int price = 80;
	private SizeFactor sizeFactor;
	public RedTea(String size) {
		sizeFactor = new TeaSizeFactor(size.toLowerCase());
		price += sizeFactor.getCost();
	}
	@Override
	public int getCost(){
		return price;
	}
}
