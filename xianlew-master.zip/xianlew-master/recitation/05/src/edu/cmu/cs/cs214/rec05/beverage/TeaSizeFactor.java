/**
 * rec5 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 30 2013
 */
package edu.cmu.cs.cs214.rec05.beverage;

/**
 * @author xianlewang
 *
 */
public final class TeaSizeFactor implements SizeFactor {

	private int price;
	public TeaSizeFactor(String size){
		switch(size){
		case "small": price = 20;break;
		case "medium": price = 50;break;
		case "large": price = 70;break;
		}
	}
	@Override
	public int getCost() {
		return price;
	}

}
