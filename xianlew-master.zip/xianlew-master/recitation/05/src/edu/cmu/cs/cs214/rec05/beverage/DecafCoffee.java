/**
 * rec5 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 30 2013
 */
package edu.cmu.cs.cs214.rec05.beverage;

/**
 * @author xianlewang
 *
 */
public final class DecafCoffee extends Coffee{
	private int price = 50;
	private SizeFactor sizeFactor;
	public DecafCoffee(String size) {
		sizeFactor = new CoffeeSizeFactor(size.toLowerCase());
		price += sizeFactor.getCost();
	}
	@Override
	public int getCost(){
		return price;
	}
}
