/**
 * rec5 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 30 2013
 */
package edu.cmu.cs.cs214.rec05.ingredients;

import edu.cmu.cs.cs214.rec05.beverage.Beverage;

/**
 * @author xianlewang
 *
 */
public final class Chocolate extends FlavoredBeverage{
	private int price = 30;
	private Beverage beverage;
	public Chocolate(Beverage beverage ){
		this.beverage = beverage;
		price+=beverage.getCost();
	}
	@Override
	public int getCost(){
		return price;
	}
}
