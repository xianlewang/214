/**
 * 
 */
package edu.cmu.cs.cs214.rec05.ingredients;

import java.util.ArrayList;

import edu.cmu.cs.cs214.rec05.beverage.Beverage;

/**
 * @author xianlewang
 *
 */
public final class WhippedCream extends FlavoredBeverage{
	private int price = 30;
	private Beverage beverage;
	public WhippedCream(Beverage beverage ){
		this.beverage = beverage;
		price+=beverage.getCost();
	}
	@Override
	public int getCost(){
		return price;
	}
}
