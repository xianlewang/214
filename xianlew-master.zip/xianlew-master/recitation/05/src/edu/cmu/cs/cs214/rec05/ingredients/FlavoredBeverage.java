/**
 * rec5 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 30 2013
 */
package edu.cmu.cs.cs214.rec05.ingredients;

import java.util.ArrayList;

import edu.cmu.cs.cs214.rec05.beverage.Beverage;

public abstract class FlavoredBeverage extends Beverage {
	private int price ;
	private Beverage beverage;
    @Override
    public int getCost() {
    	return price;
    }
    
}
