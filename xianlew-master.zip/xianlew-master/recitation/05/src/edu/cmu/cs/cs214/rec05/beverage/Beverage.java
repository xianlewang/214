/**
 * rec5 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 30 2013
 */
package edu.cmu.cs.cs214.rec05.beverage;

public abstract class Beverage {
	private int price = -1;
	private SizeFactor sizeFactor;
    /**
     * Calculates and returns the cost of the {@link Beverage}.
     *
     * @return The cost of this {@link Beverage} in cents.
     */
	public int getCost(){
		return price;
	}

}
