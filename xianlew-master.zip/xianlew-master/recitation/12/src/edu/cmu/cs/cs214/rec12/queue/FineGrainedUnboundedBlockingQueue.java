package edu.cmu.cs.cs214.rec12.queue;

import java.util.NoSuchElementException;

/**
 * Modify this class to be thread-safe and be an unbounded blocking queue. Use a
 * fine-grained locking strategy so that threads may concurrently enqueue
 * elements and dequeue elements without contention (usually).
 * 
 * The queue disallows null elements.
 * 
 * @author Danny Lu
 */
public class FineGrainedUnboundedBlockingQueue<E> implements Queue<E> {
	private Node<E> head; // A dummy node. head.next points to the first real
							// node in the queue.
	private Node<E> tail; // The last node in the queue. head == tail if the
							// queue is empty.
	private int size; // The number of elements in the queue.
	// locks
	private final Object headLock = new Object();
	private final Object tailLock = new Object();

	private static class Node<E> {
		public Node<E> next;
		public E data;

		public Node(E data) {
			this.data = data;
			this.next = null;
		}
	}

	public FineGrainedUnboundedBlockingQueue() {
		head = new Node<E>(null);
		tail = head;
		size = 0;
	}

	@Override
	public boolean isEmpty() {
		synchronized (headLock) {
			return size == 0;
		}
	}

	@Override
	public int size() {
		synchronized (headLock) {
			synchronized (tailLock) {
				return size;
			}
		}
	}

	@Override
	public E peek() {
		synchronized (headLock) {
			synchronized (tailLock) {
				if (size == 0) {
					return null;
				}
				return head.next.data;
			}
		}
	}

	@Override
	public void enqueue(E element) {
		synchronized (tailLock) {
			synchronized (tail) {
				if (element == null) {
					throw new NullPointerException();
				}
				Node<E> newTail = new Node<E>(element);
				tail.next = newTail;
				notify???
				tail = newTail;
				synchronized (this) {
					size++;
				}
			}
		}
	}

	@Override
	public E dequeue() {
		// TODO: Change this method to block (waiting for an enqueue) rather
		// than throw an exception.
		synchronized (headLock) {
			synchronized (head) {
				if (size == 0) {
					try {
						head.wait();
					} catch (InterruptedException e) {
					}
				}
				E data = head.next.data;
				head = head.next;
				head.data = null;
				synchronized (this) {
					size--;
				}
				return data;
			}
		}
	}

	@Override
	public String toString() {
		synchronized (headLock) {
			synchronized (tailLock) {
				if (size == 0) {
					return "";
				}
				StringBuilder s = new StringBuilder();
				s.append(head.next.data);
				Node<E> temp = head.next.next;
				while (temp != null) {
					s.append(" " + temp.data);
					temp = temp.next;
				}
				return s.toString();
			}
		}
	}
}
