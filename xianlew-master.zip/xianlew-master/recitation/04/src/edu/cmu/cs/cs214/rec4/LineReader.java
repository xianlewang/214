package edu.cmu.cs.cs214.rec4;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.IOException;

public class LineReader {

    public static void main(String[] args) {
        // String line = readFirstLine("someFile.txt");
        // System.out.println("The line was: " + line);
    }
}
