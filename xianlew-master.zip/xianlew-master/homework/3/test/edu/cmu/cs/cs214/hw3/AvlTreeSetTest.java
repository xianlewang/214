/**
 * hw3 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 26 2013
 */
package edu.cmu.cs.cs214.hw3;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AvlTreeSetTest {
	private AvlTreeSet mTestTree;

	/** Called before each test case method. */
	@Before
	public void setUp() throws Exception {
		// Start each test case method with a brand new AvlTreeSet object.
		mTestTree = new AvlTreeSet();
	}

	/** Called after each test case method. */
	@After
	public void tearDown() throws Exception {
		// Don't need to do anything here.
	}

	/** Tests that an empty tree has size 0. */
	@Test
	public void testEmptyTreeSize() {
		// First argument is the expected value.
		// Second argument is the actual returned value.
		assertEquals(0, mTestTree.size());
	}

	/**
	 * Find bug: public Node(int value, Node left, Node right) {mSize =
	 * left.size() + right.size()+1;}
	 */
	@Test
	public void testTreeSize() {
		mTestTree.insert(1);
		assertEquals(1, mTestTree.size());
	}

	@Test
	public void testInsertOne() {
		mTestTree.insert(1);
		assertTrue(mTestTree.contains(1));
	}

	@Test
	public void testInsertNegative() {
		mTestTree.insert(-1);
		assertTrue(mTestTree.contains(-1));
	}

	@Test
	public void testInsertZero() {
		mTestTree.insert(0);
		assertTrue(mTestTree.contains(0));
	}

	@Test
	public void testInsertAndRemove() {
		mTestTree.insert(10);
		mTestTree.insert(1);
		mTestTree.insert(2);
		mTestTree.remove(1);
		mTestTree.insert(6);
		mTestTree.remove(6);
		mTestTree.insert(9);
		mTestTree.insert(10);
		mTestTree.insert(22);
		mTestTree.insert(12);
		mTestTree.insert(5);
		mTestTree.insert(65);
		mTestTree.remove(65);
		mTestTree.insert(18);
		mTestTree.remove(18);
		assertEquals(6, mTestTree.size());
	}

	/**
	 * Find bug: public Node insert(int value): if (value > mValue) { return new
	 * Node(mValue, mLeft, mRight.insert(value)).balance(); }
	 */
	@Test
	public void testInsertDuplicated() {
		mTestTree.insert(1);
		mTestTree.insert(1);
		assertTrue(mTestTree.contains(1));
		assertEquals(1, mTestTree.size());
	}

	@Test
	public void testIsEmpty() {
		mTestTree.insert(1);
		mTestTree.remove(1);
		assertTrue(mTestTree.isEmpty());
	}

	@Test
	public void testRemoveExistingNode() {
		mTestTree.insert(0);
		mTestTree.insert(2);
		mTestTree.insert(1);

		mTestTree.insert(-1);
		mTestTree.remove(1);
		assertFalse(mTestTree.contains(1));

	}

	@Test(expected = IllegalStateException.class)
	public void testRemoveNonExistingNode() {
		mTestTree.insert(0);
		mTestTree.remove(1);
		assertEquals(1, mTestTree.size());
	}

	@Test
	public void testContainsEmpty() {
		assertFalse(mTestTree.contains(1));
	}

	@Test
	public void testContainsExistingNode() {
		mTestTree.insert(1);
		mTestTree.insert(-1);
		mTestTree.insert(2);
		assertTrue(mTestTree.contains(-1));
	}

	@Test
	public void testContainsNonExistingNode() {
		mTestTree.insert(0);
		assertFalse(mTestTree.contains(1));
	}

	@Test
	public void testGetMax() {
		mTestTree.insert(1);
		mTestTree.insert(9);
		mTestTree.insert(-1);
		mTestTree.insert(8);
		assertEquals(9, mTestTree.getMax());
	}

	@Test(expected = IllegalStateException.class)
	public void testGetMaxFromEmpty() {
		mTestTree.getMax();
	}

	@Test
	public void testGetMin() {
		mTestTree.insert(1);
		mTestTree.insert(9);
		mTestTree.insert(-1);
		mTestTree.insert(8);
		assertEquals(-1, mTestTree.getMin());
	}

	@Test(expected = IllegalStateException.class)
	public void testGetMinFromEmpty() {
		mTestTree.getMin();
	}

	@Test
	public void testGetHeight1() {
		assertEquals(-1, mTestTree.getHeight());
	}

	@Test
	public void testGetHeight2() {
		mTestTree.insert(1);
		mTestTree.insert(9);
		mTestTree.insert(-1);
		mTestTree.insert(8);
		assertEquals(2, mTestTree.getHeight());
	}

	@Test
	public void testGetHeight3() {
		mTestTree.insert(1);
		assertEquals(0, mTestTree.getHeight());
	}

	@Test
	public void testLL() {
		mTestTree.insert(1);
		mTestTree.insert(2);
		mTestTree.insert(3);
		assertEquals(1, mTestTree.getHeight());
	}

	@Test
	public void testLR() {
		mTestTree.insert(1);
		mTestTree.insert(3);
		mTestTree.insert(2);
		assertEquals(1, mTestTree.getHeight());
	}

	@Test
	public void testRL() {
		mTestTree.insert(3);
		mTestTree.insert(1);
		mTestTree.insert(2);
		assertEquals(1, mTestTree.getHeight());
	}

	@Test
	public void testRR() {
		mTestTree.insert(3);
		mTestTree.insert(2);
		mTestTree.insert(1);
		assertEquals(1, mTestTree.getHeight());
	}

}
