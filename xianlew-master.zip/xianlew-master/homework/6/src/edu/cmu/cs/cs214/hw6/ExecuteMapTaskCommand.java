package edu.cmu.cs.cs214.hw6;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.net.Socket;
import java.util.Iterator;
import java.util.List;

import edu.cmu.cs.cs214.hw6.util.KeyValuePair;
import edu.cmu.cs.cs214.hw6.util.Log;
import edu.cmu.cs.cs214.hw6.util.WorkerStorage;

/**
 * A {@link WorkerCommand} that executes a {@link MapTask} and sends the calculated
 * result back to the master.
 * 
 * Note that the generic type <code>T</code> must extend {@link Serializable}
 * since we will be writing it over the network back to the client using an
 * {@link ObjectOutputStream}.
 */
public class ExecuteMapTaskCommand<T extends Serializable> extends
		WorkerCommand {
	private static final long serialVersionUID = -5314076333098679665L;
	private static final String TAG = "ExecuteMapTaskCommand";
	private final List<WorkerInfo> mWorkers;
	private final WorkerInfo mWorker;
	private final MapTask mTask;
	private final Partition mP;
	private final List<WorkerInfo> orgWorkers;
	private final Emitter emitter = new Emitter() {
		
		/**
		 * 
		 */
		private static final long serialVersionUID = 507007000912372695L;

		@Override
		public void emit(String key, String value) throws IOException {
			// shuffle the intermediate result
			// Log.i(TAG, key+"|"+value);

			//int nWorker = mWorkers.size();
			int i = Math.abs(key.hashCode() % orgWorkers.size());
			StringBuilder toPath = new StringBuilder();// ;
			toPath.append(WorkerStorage.getIntermediateResultsDirectory(mWorker
					.getName()));
			toPath.append("/");
			toPath.append(orgWorkers.get(i).getName());
			// write to files
			try (PrintWriter out = new PrintWriter(new BufferedWriter(
					new FileWriter(toPath.toString(), true)))) {
				out.println(String.format("%s\t%s", key, value));
			} catch (IOException e) {
				Log.e(TAG, "Error when emit", e);
			}
		}
	};
	/**
	 * create a new command
	 * @param task
	 * @param mP the partition to map from
	 * @param mWorker 
	 * @param mWorkers 
	 * @param orgWorkers information of all the workers(includes dead worker)
	 */
	public ExecuteMapTaskCommand(MapTask task, Partition mP,
			WorkerInfo mWorker, List<WorkerInfo> mWorkers, List<WorkerInfo> orgWorkers) {
		mTask = task;
		this.mP = mP;
		this.mWorkers = mWorkers;
		this.mWorker = mWorker;
		this.orgWorkers = orgWorkers;
	}

	@Override
	public void run() {

		Socket socket = getSocket();
		Boolean result = false;
		FileInputStream in = null;
		try {
			for (File f : mP) {
				in = new FileInputStream(f);
				mTask.execute(in, emitter);
			}

			in.close();
			result = true;
		} catch (Exception e) {
			Log.e(TAG, "I/O error while executing task.", e);
			result = false;
		} finally {
			try {
				ObjectOutputStream out = new ObjectOutputStream(
						socket.getOutputStream());
				out.writeObject(result);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
