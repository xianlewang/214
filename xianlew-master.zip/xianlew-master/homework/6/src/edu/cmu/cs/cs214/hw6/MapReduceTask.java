/**
 * 
 */
package edu.cmu.cs.cs214.hw6;

import java.io.Serializable;

/**
 * @author xianlewang
 * A container class to contain mapTask and reduceTaks
 */
public class MapReduceTask implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5996034919061220439L;
	private final MapTask map;
	private final ReduceTask reduce;
	
	public MapReduceTask(MapTask map,ReduceTask reduce){
		this.map = map;
		this.reduce = reduce;
	}
	
	public MapTask getMapTast(){
		return map;
	}
	public ReduceTask getReduceTask(){
		return reduce;
	}
}
