package edu.cmu.cs.cs214.hw6.plugin.wordprefix;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import edu.cmu.cs.cs214.hw6.Emitter;
import edu.cmu.cs.cs214.hw6.ReduceTask;

/**
 * The reduce task for a word-prefix map/reduce computation.
 */
public class WordPrefixReduceTask implements ReduceTask {
	private static final long serialVersionUID = 6763871961687287020L;

	@Override
	public void execute(String key, Iterator<String> values, Emitter emitter)
			throws IOException {
		Map<String, MyInteger> list = new HashMap<String, MyInteger>();
		String topS = null;
		int topN = 0;
		while(values.hasNext()){
			String w = values.next();
			if(list.containsKey(w)){
				MyInteger i = list.get(w);
				i.add(1);
				if(i.getValue()>topN){
					topN = i.getValue();
					topS = w;
				}
			}else{
				list.put(w, new MyInteger(1));
				if(1>topN){
					topN = 1;
					topS = w;
				}
			}
		}
		emitter.emit(key, topS);
		
	}
	private static class MyInteger{
		private int i;
		public MyInteger(int i){
			this.i = i;
		}
		public void add(int j){
			i+=j;
		}
		public int getValue(){
			return i;
		}
	}
	

}
