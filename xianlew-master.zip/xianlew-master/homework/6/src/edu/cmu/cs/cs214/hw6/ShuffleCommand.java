/**
 * 
 */
package edu.cmu.cs.cs214.hw6;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.Scanner;
import java.util.Set;

import edu.cmu.cs.cs214.hw6.util.KeyValuePair;
import edu.cmu.cs.cs214.hw6.util.Log;
import edu.cmu.cs.cs214.hw6.util.WorkerStorage;

/**
 * @author xianlewang
 * Command to send back client's intermediate file
 */
public class ShuffleCommand<T extends Serializable> extends WorkerCommand {

	private static final String TAG = "ShuffleCommand";
	private final WorkerInfo clientWorker;
	private final WorkerInfo mWorker;
	private final Set<String> targetNames;
	/**
	 * 
	 */
	private static final long serialVersionUID = -2646827540512265536L;
	/**
	 * create a shuffle command
	 * @param clientWorker 
	 * @param w worker
	 * @param targetNames target file names
	 */
	public ShuffleCommand(WorkerInfo clientWorker, WorkerInfo w,
			Set<String> targetNames) {
		this.clientWorker = clientWorker;
		this.mWorker = w;
		this.targetNames = targetNames;
	}

	@Override
	public void run() {
		Socket mSocket = getSocket();
		ObjectOutputStream out;
		try {
			out = new ObjectOutputStream(mSocket.getOutputStream());
			for (String name : targetNames) {
				// read the file
				StringBuilder fromPath = new StringBuilder();// ;
				fromPath.append(WorkerStorage
						.getIntermediateResultsDirectory(mWorker.getName()));
				fromPath.append("/");
				fromPath.append(name);
				try (Scanner scanner = new Scanner(new BufferedReader(
						new FileReader(fromPath.toString())))) {
					while (scanner.hasNextLine()) {
						String[] line = scanner.nextLine().trim().split("\t");
						// Log.i(TAG, "new line: "+line);
						if (line.length == 2){
							out.writeObject(new KeyValuePair(line[0], line[1]));
						}else{
							Log.i(TAG,"null line when shuffle! line: "+line.toString());
						}
					}
				}
			}
			out.writeObject(KeyValuePair.EMPTY);
			out.close();
		} catch (IOException e) {
			Log.e(TAG, "Error when shuffle", e);
		}

	}

}
