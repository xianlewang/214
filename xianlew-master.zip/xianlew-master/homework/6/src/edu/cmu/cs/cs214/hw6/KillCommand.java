/**
 * 
 */
package edu.cmu.cs.cs214.hw6;

import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;

/**
 * @author xianlewang
 * command to kill a worker
 */
public class KillCommand<T extends Serializable> extends WorkerCommand {


	/**
	 * 
	 */
	private static final long serialVersionUID = 172757620599342905L;

	public KillCommand() {

	}

	@Override
	public void run() {
		Socket mSocket = getSocket();
		ObjectOutputStream out;
		System.exit(0);
	}

}
