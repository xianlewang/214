package edu.cmu.cs.cs214.hw6;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import edu.cmu.cs.cs214.hw6.util.Log;
import edu.cmu.cs.cs214.hw6.util.StaffUtils;

/**
 * This class represents the "master server" in the distributed map/reduce
 * framework. The {@link MasterServer} is in charge of managing the entire
 * map/reduce computation from beginning to end. The {@link MasterServer}
 * listens for incoming client connections on a distinct host/port address, and
 * is passed an array of {@link WorkerInfo} objects when it is first initialized
 * that provides it with necessary information about each of the available
 * workers in the system (i.e. each worker's name, host address, port number,
 * and the set of {@link Partition}s it stores). A single map/reduce computation
 * managed by the {@link MasterServer} will typically behave as follows:
 * 
 * <ol>
 * <li>Wait for the client to submit a map/reduce task.</li>
 * <li>Distribute the {@link MapTask} across a set of "map-workers" and wait for
 * all map-workers to complete.</li>
 * <li>Distribute the {@link ReduceTask} across a set of "reduce-workers" and
 * wait for all reduce-workers to complete.</li>
 * <li>Write the final key/value pair results of the computation back to the
 * client.</li>
 * </ol>
 */
public class MasterServer extends Thread {
	private final int mPort;
	private final List<WorkerInfo> orgWokers;
	private static final String TAG = "Master";
	private static final int POOL_SIZE = Runtime.getRuntime()
			.availableProcessors();
	private final ExecutorService mExecutor;
	// private One2N<String, WorkerInfo> patitionWorkerMap = new One2N<String,
	// WorkerInfo>();
	private List<WorkerInfo> avaWorkers = new ArrayList<WorkerInfo>();
	private Set<WorkerInfo> deadWorkers = new HashSet<WorkerInfo>();
	private StringBuffer finalResult = new StringBuffer();

	/**
	 * The {@link MasterServer} constructor.
	 * 
	 * @param masterPort
	 *            The port to listen on.
	 * @param workers
	 *            Information about each of the available workers in the system.
	 */
	public MasterServer(int masterPort, List<WorkerInfo> workers) {
		mPort = masterPort;
		orgWokers = workers;
		for (WorkerInfo f : orgWokers) {
			avaWorkers.add(f);
		}
		Log.i(TAG, "new master, port: " + mPort);
		mExecutor = Executors.newFixedThreadPool(POOL_SIZE);
	}

	/**
	 * from worker-partition to partition-worker
	 * 
	 * @return Patition-Worker-Map
	 */
	private One2N<String, WorkerInfo> getPWMap(List<WorkerInfo> mWorkers) {
		One2N<String, WorkerInfo> patitionWorkerMap = new One2N<String, WorkerInfo>();
		for (WorkerInfo worker : mWorkers) {
			for (Partition p : worker.getPartitions()) {
				patitionWorkerMap.add(p.getPartitionName(), worker);
			}
		}
		return patitionWorkerMap;
	}

	/**
	 * 
	 * @param mapTaks
	 *            task to do
	 * @param mWorkers
	 *            available workers
	 * @param parts
	 *            partitions to do
	 * 
	 * @return mapCallables
	 * 
	 * 
	 */
	private List<MapCallable> distributeMapCallables(MapTask mapTaks,
			List<WorkerInfo> mWorkers, Set<String> partNames,
			One2N<WorkerInfo, String> jobLog) {
		List<MapCallable> mapCallables = new ArrayList<MapCallable>();
		Set<String> tmpPName = new HashSet<String>();
		while (tmpPName.size() < partNames.size()) {
			for (WorkerInfo w : mWorkers) {
				for (Partition p : w.getPartitions()) {
					String pName = p.getPartitionName();
					if (partNames.contains(pName) && !tmpPName.contains(pName)) {
						tmpPName.add(pName);
						mapCallables.add(new MapCallable(mapTaks, w, p,
								mWorkers, orgWokers));
						jobLog.add(w, pName);
						Log.i(TAG, "distribute: " + w.getName() + " | " + pName);
						break;
					}
				}
			}
		}
		return mapCallables;
	}

	@Override
	public void run() {
		// Wait for the client to submit a map/reduce task.
		try {
			ServerSocket serverSocket = null;
			try {
				serverSocket = new ServerSocket(mPort);
			} catch (IOException e) {
				Log.e(TAG, "Could not open server socket on port " + mPort
						+ ".", e);
				return;
			}

			Log.i(TAG, "Listening for incoming commands on port " + mPort + ".");

			while (true) {
				try {
					Socket clientSocket = serverSocket.accept();
					// get the MapReduce task
					ObjectInputStream in = new ObjectInputStream(
							clientSocket.getInputStream());
					MapReduceTask task = (MapReduceTask) in.readObject();
					MapTask mapTaks = task.getMapTast();
					ReduceTask reduceTask = task.getReduceTask();
					finalResult = new StringBuffer();
					/*
					 * Map
					 */
					// get a list of todo partition name
					Set<String> partNames = getPWMap(avaWorkers).getKeyList();
					One2N<WorkerInfo, String> mapLog = doMap(mapTaks, partNames);
					/*
					 * shuffle and reduce
					 */
					List<WorkerInfo> downWorkers;
					do {
						downWorkers = doReduce(reduceTask);

						if (downWorkers.size() > 0) {
							Log.i(TAG, "recover from reduce");
							Set<String> redoParts = new HashSet<String>();
							for (WorkerInfo w : downWorkers) {
								redoParts.addAll(mapLog.get(w));
							}
							mapLog = doMap(mapTaks, redoParts);
						}
					} while (downWorkers.size() > 0);

				} catch (IOException e) {
					Log.e(TAG,
							"Error while listening for incoming connections.",
							e);
					break;
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
				Log.i(TAG, "Reduce done!");
			}

			Log.i(TAG, "Shutting down...");

			try {
				serverSocket.close();
			} catch (IOException e) {
				// Ignore because we're about to exit anyway.
			}
		} finally {
			mExecutor.shutdown();
		}
	}

	/**
	 * do a reduce job on all available workers
	 * 
	 * @param reduceTask
	 * @return a list of dead workers
	 */
	private List<WorkerInfo> doReduce(ReduceTask reduceTask) {
		Log.i(TAG, "start shuffle");
		List<ReduceCallable> reduceCallables = new ArrayList<ReduceCallable>();
		// assign local file to living reducer
		for (WorkerInfo w : avaWorkers) {
			reduceCallables = addReduceCall(reduceCallables, reduceTask, w,
					w.getName());
		}
		// assign dead file to living reducer
		int index = 0;
		for (WorkerInfo w : deadWorkers) {
			WorkerInfo subW = avaWorkers.get(index % avaWorkers.size());
			Log.i(TAG,
					"reduce recover: " + w.getName() + "file to "
							+ subW.getName());
			reduceCallables = addReduceCall(reduceCallables, reduceTask, subW,
					w.getName());
			++index;
		}
		// print list
		for (ReduceCallable r : reduceCallables) {
			String worker = r.getWorker().getName();
			String work = Arrays.toString(r.getTargetNames().toArray());
			Log.i(TAG, "Reduce: " + worker + "--------" + work);
		}
		// gather result
		List<Future<String>> results = null;
		try {
			results = mExecutor.invokeAll(reduceCallables);
		} catch (InterruptedException e) {
			Log.i(TAG, "interrupt");
			Thread.currentThread().interrupt();
		}
		List<WorkerInfo> errorOut = new ArrayList<WorkerInfo>();
		StringBuilder succOut = new StringBuilder();
		for (int i = 0; i < results.size(); ++i) {
			Future<String> fr = results.get(i);
			String r;
			try {
				r = fr.get();
			} catch (InterruptedException | ExecutionException e) {
				r = null;
			}
			WorkerInfo tmpWorker = reduceCallables.get(i).getWorker();
			if (r == null) {
				errorOut.add(tmpWorker);
			} else {
				succOut.append(r);
			}
		}
		if (errorOut.size() == 0) {
			finalResult.append(succOut.toString());
		}

		return errorOut;
	}

	private List<ReduceCallable> addReduceCall(
			List<ReduceCallable> reduceCallables, ReduceTask reduceTask,
			WorkerInfo worker, String targetName) {
		for (ReduceCallable call : reduceCallables) {
			if (call.getWorker().equals(worker)) {
				call.getTargetNames().add(targetName);
				return reduceCallables;
			}
		}
		Set<String> names = new HashSet<String>();
		names.add(targetName);
		reduceCallables.add(new ReduceCallable(reduceTask, worker, avaWorkers,
				names));
		return reduceCallables;
	}

	/**
	 * do map job
	 * 
	 * @param mapTaks
	 * @param partNames
	 *            a set of partitions to map
	 * @return job log
	 */
	private One2N<WorkerInfo, String> doMap(MapTask mapTaks,
			Set<String> partNames) {

		// distribute partitions
		One2N<WorkerInfo, String> jobLog = new One2N<WorkerInfo, String>();
		List<MapCallable> mapCallables = distributeMapCallables(mapTaks,
				avaWorkers, partNames, jobLog);
		List<Future<Boolean>> results = null;
		try {
			Log.i(TAG, "start map");
			results = mExecutor.invokeAll(mapCallables);
		} catch (InterruptedException e) {
			Log.i(TAG, "interrupt");
			Thread.currentThread().interrupt();
		}
		Log.i(TAG, "do map once");
		// failure recover
		boolean flag = false;
		do {
			flag = false;
			// get a list of part names to redo
			Set<String> rePartNames = new HashSet<String>();
			for (int i = 0; i < results.size(); ++i) {
				Future<Boolean> f = results.get(i);
				try {
					Boolean finish = f.get();
					WorkerInfo tmpW = mapCallables.get(i).getWorker();
					// if new failure happened
					if (!deadWorkers.contains(tmpW) && !finish) {
						flag = true;
						rePartNames.addAll(jobLog.get(tmpW));
						avaWorkers.remove(tmpW);
						deadWorkers.add(tmpW);
					}
				} catch (Exception e) {
					// if can't get result of this worker
					flag = true;
					WorkerInfo tmpW = mapCallables.get(i).getWorker();
					if (!deadWorkers.contains(tmpW)) {
						rePartNames.addAll(jobLog.get(tmpW));
						avaWorkers.remove(tmpW);
						deadWorkers.add(tmpW);
					}
				}
			}
			// re-distribute
			// update log
			for (WorkerInfo dead : deadWorkers) {
				jobLog.delete(dead);
			}
			if (flag) {
				Log.i(TAG, "recover from map");
				mapCallables = distributeMapCallables(mapTaks, avaWorkers,
						rePartNames, jobLog);
				// jobLog = getJobLog(mapCallables);
				// re-map
				results = null;
				try {
					results = mExecutor.invokeAll(mapCallables);
					Log.i(TAG, "map again!");
				} catch (InterruptedException e) {
					Log.i(TAG, "interrupt");
					Thread.currentThread().interrupt();
				}
			}
		} while (flag);

		return jobLog;
	}

	/**
	 * help class to send a map command to a worker
	 * 
	 * @author xianlewang
	 * 
	 */
	private static class MapCallable implements Callable<Boolean> {
		private final MapTask mTask;
		private final WorkerInfo mWorker;
		private final List<WorkerInfo> toWorkers;
		private final Partition mP;
		private final List<WorkerInfo> orgWorkers;

		/**
		 * create a callable
		 * 
		 * @param task
		 * @param worker
		 * @param p
		 *            the target partititon
		 * @param workers
		 *            the worker to do the job
		 * @param orgWorkers
		 *            info of all workers
		 */
		public MapCallable(MapTask task, WorkerInfo worker, Partition p,
				List<WorkerInfo> workers, List<WorkerInfo> orgWorkers) {
			mTask = task;
			mWorker = worker;
			toWorkers = workers;
			mP = p;
			this.orgWorkers = orgWorkers;
		}

		public Partition getPartition() {
			return mP;
		}

		/**
		 * Returns the {@link WorkerConfig} object that provides information
		 * about the worker that this callable task is responsible for
		 * interacting with.
		 */
		public WorkerInfo getWorker() {
			return mWorker;
		}

		@Override
		public Boolean call() {
			Socket socket = null;
			try {
				// Establish a connection with the worker server.
				socket = new Socket(mWorker.getHost(), mWorker.getPort());

				ObjectOutputStream out = new ObjectOutputStream(
						socket.getOutputStream());
				out.writeObject(new ExecuteMapTaskCommand<Boolean>(mTask, mP,
						mWorker, toWorkers, orgWorkers));

				ObjectInputStream in = new ObjectInputStream(
						socket.getInputStream());

				// Read and return the worker's final result.
				return (Boolean) in.readObject();
			} catch (Exception e) {
				return false;
			} finally {
				try {
					if (socket != null) {
						socket.close();
					}
				} catch (IOException e) {
					// Ignore because we're about to exit anyway.
				}
			}
		}
	}

	/**
	 * Help data structure to store a map, the key is A, value is a List of B
	 * 
	 * @author xianlewang
	 * 
	 * @param <A>
	 *            key
	 * @param <B>
	 *            list value element
	 */
	private static class One2N<A extends Serializable, B extends Serializable>
			implements Serializable {

		/**
		 * 
		 */
		private static final long serialVersionUID = 5886879061897019782L;
		private final Map<A, List<B>> list = new HashMap<A, List<B>>();

		public void delete(A dead) {
			if (list.containsKey(dead))
				list.remove(dead);
		}

		public Set<A> getKeyList() {
			// List<String> l = new ArrayList<String>();
			// for (Object e : list.keySet().toArray()) {
			// l.add((String) e);
			// }
			return (Set<A>) list.keySet();
		}

		public int size() {
			return list.size();
		}

		public boolean containsKey(A key) {
			return list.containsKey(key);
		}
		/**
		 * add a record (a,b). If a is already exist, add b to the value list of a
		 * @param a key
		 * @param b element of value list
		 */
		public void add(A a, B b) {
			if (list.containsKey(a)) {
				if (!list.get(a).contains(b))
					list.get(a).add(b);
			} else {
				List<B> set = new ArrayList<B>();
				set.add(b);
				list.put(a, set);
			}
		}
		/**
		 * get value list
		 * @param a key
		 * @return value list
		 */
		public List<B> get(A a) {
			return list.get(a);
		}
	}

	/**
	 * assign a reduce task with certain targetFileNames to a worker
	 * @author xianlewang
	 *
	 */
	private static class ReduceCallable implements Callable<String> {
		private final ReduceTask mTask;
		private final WorkerInfo mWorker;
		private final List<WorkerInfo> mWorkers;
		private final Set<String> targetNames;

		public ReduceCallable(ReduceTask task, WorkerInfo worker,
				List<WorkerInfo> mWorkers, Set<String> targetName) {
			mTask = task;
			mWorker = worker;
			this.mWorkers = mWorkers;
			this.targetNames = targetName;
		}

		/**
		 * Returns the {@link WorkerConfig} object that provides information
		 * about the worker that this callable task is responsible for
		 * interacting with.
		 */
		public WorkerInfo getWorker() {
			return mWorker;
		}

		public Set<String> getTargetNames() {
			return targetNames;
		}

		@Override
		public String call() {
			Socket socket = null;
			try {
				// Establish a connection with the worker server.
				socket = new Socket(mWorker.getHost(), mWorker.getPort());

				// Create the ObjectOutputStream and write the WorkerCommand
				// over the network to be read and executed by a WorkerServer.
				ObjectOutputStream out = new ObjectOutputStream(
						socket.getOutputStream());
				out.writeObject(new ExecuteReduceTaskCommand<Boolean>(mTask,
						mWorker, mWorkers, targetNames));
				ObjectInputStream in = new ObjectInputStream(
						socket.getInputStream());

				// Read and return the worker's final result.
				return (String) in.readObject();
			} catch (Exception e) {
				return null;
			} finally {
				try {
					if (socket != null) {
						socket.close();
					}
				} catch (IOException e) {
					// Ignore because we're about to exit anyway.
				}
			}
		}
	}

	/********************************************************************/
	/***************** STAFF CODE BELOW. DO NOT MODIFY. *****************/
	/********************************************************************/

	/**
	 * Starts the master server on a distinct port. Information about each
	 * available worker in the distributed system is parsed and passed as an
	 * argument to the {@link MasterServer} constructor. This information can be
	 * either specified via command line arguments or via system properties
	 * specified in the <code>master.properties</code> and
	 * <code>workers.properties</code> file (if no command line arguments are
	 * specified).
	 */
	public static void main(String[] args) {
		StaffUtils.makeMasterServer(args).start();
	}

}
