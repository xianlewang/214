package edu.cmu.cs.cs214.hw6;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import edu.cmu.cs.cs214.hw6.util.Log;
/**
 * Run this killer to kill a worker on port *
 * @author xianlewang
 *
 */
public class Killer {

	public static void main(String[] args) throws IOException {
		Socket socket = null;
        try {
            // Establish a connection with the worker server.
        	int port = 15214;
            socket = new Socket("localhost", port);

            // Create the ObjectOutputStream and write the WorkerCommand
            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            out.writeObject(new KillCommand());
            Log.e("KILLER", "kill:"+port);
        } catch (UnknownHostException e) {
			e.printStackTrace();
		}
	}
	

}
