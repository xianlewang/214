package edu.cmu.cs.cs214.hw6;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import edu.cmu.cs.cs214.hw6.util.KeyValuePair;
import edu.cmu.cs.cs214.hw6.util.Log;
import edu.cmu.cs.cs214.hw6.util.WorkerStorage;

/**
 * A {@link WorkerCommand} that executes a {@link ReduceTask} and sends the calculated
 * result back to the master.
 * 
 * Note that the generic type <code>T</code> must extend {@link Serializable}
 * since we will be writing it over the network back to the client using an
 * {@link ObjectOutputStream}.
 */
public class ExecuteReduceTaskCommand<T extends Serializable> extends
		WorkerCommand {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1539654603105921955L;
	private static final String TAG = "ExecuteReduceTaskCommand";
	private final List<WorkerInfo> mWorkers;
	private final WorkerInfo mWorker;
	private final ReduceTask mTask;
	private final Set<String> targetNames;
	private final Map<String, Itr<String>> result = new HashMap<String, Itr<String>>();
	private String returnValue;
	String toPath;
	private final Emitter emitter = new Emitter() {
		/**
		 * 
		 */
		private static final long serialVersionUID = -1277297356787762576L;
		
		@Override
		public void emit(String key, String value) throws IOException {
			// set return value
			//System.out.println("toPath in emit:"+toPath);
			if (returnValue == null)
				returnValue = toPath.toString();

			// write to files
			try (PrintWriter out = new PrintWriter(new BufferedWriter(
					new FileWriter(toPath.toString(), true)))) {
				out.println(String.format("%s\t%s", key, value));
			} catch (IOException e) {
				Log.e(TAG, "Error when emit", e);
			}
		}
	};
	/**
	 * create a reduce command
	 * @param task
	 * @param mWorker
	 * @param mWorkers
	 * @param targetNames the filename 
	 */
	public ExecuteReduceTaskCommand(ReduceTask task, WorkerInfo mWorker,
			List<WorkerInfo> mWorkers, Set<String> targetNames) {
		mTask = task;
		this.mWorkers = mWorkers;
		this.mWorker = mWorker;
		this.targetNames = targetNames;
		toPath = WorkerStorage.getFinalResultsDirectory(mWorker.getName())+ "/result";
		Log.i(TAG, "path: "+toPath);
		// StringBuilder toPath = new StringBuilder();// ;
		// toPath.append();
		// toPath.append("/result");
		// mExecutor = Executors.newFixedThreadPool(POOL_SIZE);
	}

	@Override
	public void run() {
		/*
		 * clean up
		 */
		try{
		new File(toPath).deleteOnExit();
		}catch(Exception e){
			System.out.println("cannot delete");
		}
		/*
		 * shuffle
		 */
		// pull data from other workers
		for (WorkerInfo sourceW : mWorkers) {
			/*
			 * need do multithread here!!!!!!
			 */
			if (true) {//
				Socket shuffleSocket = null;
				try {
					// Establish a connection with the worker server.
					shuffleSocket = new Socket(sourceW.getHost(),
							sourceW.getPort());

					ObjectOutputStream out = new ObjectOutputStream(
							shuffleSocket.getOutputStream());
					out.writeObject(new ShuffleCommand<Boolean>(mWorker,
							sourceW, targetNames));

					ObjectInputStream in = new ObjectInputStream(
							shuffleSocket.getInputStream());
					updateResult(in);
					in.close();
				} catch (ClassNotFoundException | IOException e) {
					e.printStackTrace();
				} finally {
					try {
						if (shuffleSocket != null) {
							shuffleSocket.close();
						}
					} catch (IOException e) {
						// Ignore because we're about to exit anyway.
					}
				}
			}
		}

		/*
		 * reduce
		 */
		Log.i(TAG, "reduce-emiting");
		try {
			for (Entry<String, Itr<String>> set : result.entrySet()) {
				mTask.execute(set.getKey(),
						(Itr<String>) (Itr<?>) set.getValue(), emitter);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// return result
		try {
			ObjectOutputStream out = new ObjectOutputStream(getSocket()
					.getOutputStream());
			out.writeObject(returnValue);
		} catch (IOException e) {
		}
	}

	private void updateResult(ObjectInputStream in)
			throws ClassNotFoundException, IOException {
		KeyValuePair kp = (KeyValuePair) in.readObject();

		while (kp != null && !kp.equals(KeyValuePair.EMPTY)) {
			synchronized (result) {
				String key = kp.getKey();
				if (result.containsKey(key)) {
					result.get(key).add(kp.getValue());
				} else {
					Itr<String> value = new Itr<String>();
					value.add(kp.getValue());
					result.put(key, value);
				}
			}

			kp = (KeyValuePair) in.readObject();
		}
	}

	private static class Itr<T extends Serializable> implements Serializable,
			Iterator<T> {
		private List<T> list = new ArrayList<T>();
		/**
		 * 
		 */
		private static final long serialVersionUID = -419206043524741155L;

		@Override
		public boolean hasNext() {
			return list.size() > 0;
		}

		@Override
		public T next() {
			return list.remove(0);
		}

		@Override
		public void remove() {
			list.remove(list.size() - 1);
		}

		public void add(T e) {
			list.add(e);
		}

	}

}
