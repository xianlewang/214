#!/bin/bash


root='/home/xianlewang/15214/xianlew/homework/6/worker_storage/worker'
po='/intermediate_results/*'
fn='/final_results/*'
for((i=1;i<5;i++)); do
    rm $root$i$po
    rm $root$i$fn
done 