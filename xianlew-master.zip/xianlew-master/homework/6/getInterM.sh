read toFile
root='/home/xianlewang/15214/xianlew/homework/6/worker_storage/worker'
po='/intermediate_results/*'
for((i=1;i<5;i++)); do
    cat $root$i$po >>$toFile
done 