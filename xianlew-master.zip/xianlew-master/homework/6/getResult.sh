read toFile
root='/home/xianlewang/15214/xianlew/homework/6/worker_storage/worker'
fn='/final_results/result'
for((i=1;i<5;i++)); do
    cat $root$i$fn >>$toFile
done 