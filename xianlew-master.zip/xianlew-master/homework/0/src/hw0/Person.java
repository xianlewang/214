/**
 * hw0 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Aug. 31 2013
 */
package hw0;

/**
 * Person class is used to represent a person
 * 
 * @author xianlewang
 */
public class Person {

	public boolean wasVst;
	public String name;
	public int dist;

	/**
	 * Default constructor method
	 */
	public Person() {
	};

	/**
	 * Constructor method used to define a person with name, and set default
	 * value of the flags.
	 * 
	 * @param name
	 *            the name of the person
	 */
	public Person(String name) {
		this.name = name;
		wasVst = false;
		dist = 0;

	}

}
