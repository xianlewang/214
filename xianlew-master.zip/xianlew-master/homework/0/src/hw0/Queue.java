/**
 * hw0 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Aug. 31 2013
 */
package hw0;

/**
 * Queue class represents a data structure which follows the first-in first-out
 * rule.
 * 
 * @author xianlewang
 * 
 */
public class Queue<T> {

	private T[] Q;
	private int CAPACITY = 50;
	private int front;
	private int back;
	private int n;

	/**
	 * Constructor method. Set the default value to the filed.
	 */
	public Queue() {
		Q = (T[]) new Object[CAPACITY];
		front = 0;
		back = -1;
		n = 0;
	}

	/**
	 * The method used to push a new person into the queue.
	 * 
	 * @param person
	 *            the new person in the queue
	 */
	public void enqueue(T person) {
		if (n >= Q.length)
			throw new RuntimeException("Full queue");
		Q[++back % Q.length] = person;
		++n;
	}

	/**
	 * The method used to pull a person out of the queue.
	 * 
	 * @return the person at the head of the queue
	 */
	public T dequeue() {
		if (isEmpty())
			throw new RuntimeException("Empty queue");
		T tmp = Q[front % Q.length];
		Q[front % Q.length] = null;
		++front;
		--n;
		return tmp;
	}

	/**
	 * The method used to test if the queue is empty.
	 * 
	 * @return true if the queue is empty
	 */
	public boolean isEmpty() {
		return n <= 0 ? true : false;
	}

}
