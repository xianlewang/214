/**
 * hw0 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: August 31 2013
 */
package hw0;

/**
 * FriendGraph is a class that can represent friendships in a social network and
 * can compute the distance between two people in the graph. The upper limit of
 * the number of people is 50.
 * 
 * @author xianlewang
 */
public class FriendGraph {

	private final int MAX = 50;
	private Person people[];
	private int mat[][];
	private int nPeople;
	private Queue<Integer> Q;

	/**
	 * Constructor of the FriendFraph class
	 */
	public FriendGraph() {
		people = new Person[MAX];
		mat = new int[MAX][MAX];
		nPeople = 0;
		Q = new Queue<Integer>();
		for (int n = 0; n < MAX; ++n) {
			for (int m = 0; m < MAX; ++m) {
				mat[n][m] = 0;
			}
		}
	}

	/**
	 * The method used for adding a new person into the graph.
	 * 
	 * @param person
	 *            the new person to add in
	 */
	public void addPerson(Person person) {
		if (nPeople >= MAX) {
			throw new RuntimeException(" too many people");
		}
		people[nPeople] = person;
		++nPeople;
	}

	/**
	 * The method used to add a new friendship into the graph.
	 * 
	 * @param a
	 *            the name of one person
	 * @param b
	 *            the name of the other person
	 */
	public void addFriendship(String a, String b) {
		int m = getPerson(a);
		int n = getPerson(b);
		if (m == -1 || n == -1)
			throw new RuntimeException("wrong name");
		mat[m][n] = 1;
		mat[n][m] = 1;
	}

	/**
	 * The method used to calculate the distance between two people in the
	 * graph.
	 * 
	 * @param a
	 *            the name of one person
	 * @param b
	 *            the name of the other person
	 * @return the distance, return -1 if they are not friend
	 */
	public int getDistance(String a, String b) {
		cleanFlag();
		int start = getPerson(a);
		int end = getPerson(b);
		if (start == -1 || end == -1)
			throw new RuntimeException("wrong name");
		people[start].wasVst = true;
		people[start].dist = 0;
		Q.enqueue(start);
		int frd;
		while (!Q.isEmpty()) {
			int curr = Q.dequeue();
			if (curr == end) {
				
				int tmp = people[curr].dist;
				cleanFlag();
				return tmp;
			}
			while ((frd = getFriendID(curr)) != -1) {

				people[frd].wasVst = true;
				people[frd].dist = people[curr].dist + 1;
				Q.enqueue(frd);
			}
		}
		cleanFlag();
		return -1;

	}

	private int getFriendID(int person) {
		for (int n = 0; n < nPeople; ++n) {
			if (mat[person][n] == 1 && people[n].wasVst == false) {
				return n;
			}
		}
		return -1;
	}

	private int getPerson(String name) {
		for (int i = 0; i < nPeople; ++i) {
			Person person = people[i];
			if (person.name == name)
				return i;
		}
		return -1;
	}

	private void cleanFlag() {
		for (int i = 0; i < nPeople; ++i) {
			Person p = people[i];
			p.wasVst = false;
			p.dist = 0;
		}
		Q = new Queue<Integer>();
	}

	
	/**
	 * The test method
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		FriendGraph graph = new FriendGraph();
		Person a = new Person("a");
		Person b = new Person("b");
		Person c = new Person("c");
		Person d = new Person("d");
		Person e = new Person("e");
		Person f = new Person("f");
		graph.addPerson(a);
		graph.addPerson(b);
		graph.addPerson(c);
		graph.addPerson(d);
		graph.addPerson(e);
		graph.addPerson(f);
		graph.addFriendship("a", "b");
		graph.addFriendship("b", "c");
		graph.addFriendship("c", "d");
		graph.addFriendship("d", "e");
		graph.addFriendship("e", "f");
		graph.addFriendship("c", "a");
		graph.addFriendship("a", "f");
		//graph.printMat();
		
		System.out.println(graph.getDistance("a", "b")); 
		System.out.println(graph.getDistance("a", "c")); 
		System.out.println(graph.getDistance("a", "f")); 
		System.out.println(graph.getDistance("b", "f")); 
	}

}
