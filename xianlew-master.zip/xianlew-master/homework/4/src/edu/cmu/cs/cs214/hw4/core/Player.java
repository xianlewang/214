/**
 * 
 */
package edu.cmu.cs.cs214.hw4.core;

/**
 * @author xianlewang player class
 */
public interface Player {
	/**
	 * get the inventory
	 * 
	 * @return inventory
	 */
	public Inventory getInventory();

	/**
	 * add a special tile to the inventory
	 * 
	 * @param tile
	 *            tile
	 */
	public void addTile(Tile tile);

	/**
	 * pop out a tile
	 * 
	 * @param index
	 *            the index of tile in the inventory
	 * @return the tile
	 */
	public Tile popTile(int index);

	/**
	 * get the score
	 * 
	 * @return score
	 */
	public int getScore();

	/**
	 * set the score
	 * 
	 * @param score
	 *            score
	 */
	public void setScore(int score);

	/**
	 * get the name
	 * 
	 * @return name
	 */
	public String getName();

	/**
	 * set the name
	 * 
	 * @param name
	 *            name
	 */
	public void setName(String name);

	/**
	 * refresh the inventory
	 */
	public void changeInv();

}
