/**
 * 
 */
package edu.cmu.cs.cs214.hw4.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * @author xianlewang
 * The class used to generate letter tiles
 */
public class Bag {
	private static List<Tile> tiles = null;
	private static Random random = new Random();
	private static void creatBag(){
		String tmp = "AAAAAAAAABBCCDDDDEEEEEEEEEEEEFFGGGHHIIIIIIIIIJKLLLLMMNNNNNNOOOOOOOOPPQRRRRRRSSSSTTTTTTUUUUVVWWXYYZ";
		tiles = new ArrayList<Tile>(0);
		
		for(int i = 0; i<tmp.length(); ++i){
			String letter = String.valueOf(tmp.charAt(i));
			int score = Values.letterValue(letter);
			tiles.add(new LetterTile(letter,score ));
		}
	}
	/**
	 * get a list of LetterTiles
	 * @param num
	 * @return a list of LetterTiles
	 */
	public static List<Tile> pop(int num){
		if(tiles == null)
			creatBag();
		
		ArrayList<Tile> result = new ArrayList<>(0);
		while(num>0){
			--num;
			result.add(tiles.get(random.nextInt(tiles.size())));
		}
		return result;
	}
}
