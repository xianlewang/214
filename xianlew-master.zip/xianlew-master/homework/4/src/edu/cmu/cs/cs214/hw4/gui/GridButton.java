/**
 * 
 */
package edu.cmu.cs.cs214.hw4.gui;

import java.awt.Color;

import javax.swing.JButton;
import javax.swing.border.Border;
import javax.swing.border.MatteBorder;

/**
 * @author xianlewang
 *
 */
public class GridButton extends JButton{
	private int index;
	public GridButton(int index){
		this.index = index;
		this.setActionCommand("GRID");
		this.setFocusable(false);
	}
	@Override
	public void setText(String text){
		super.setText(text);
		MyColor.setColor(text, this);
	}
	@Override
	public void setEnabled(boolean b){
		super.setEnabled(b);
		this.setBorder(new MatteBorder(3,3,3,3,Color.MAGENTA));
		this.setBorderPainted(b);

	}
	public int getIndex(){
		return index;
	}
	
}
