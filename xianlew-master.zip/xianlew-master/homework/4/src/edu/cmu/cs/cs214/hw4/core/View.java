/**
 * 
 */
package edu.cmu.cs.cs214.hw4.core;

import java.util.List;
import java.util.Set;

/**
 * @author xianlewang
 * View class
 */
public class View {
	private Inventory myInventory;
	private List<Grid> board;
	private Set<Location> accessable;
	private Player currPlayer;

	/**
	 * constructor a view
	 * 
	 * @param inv
	 * @param board
	 * @param currPlayer
	 * @param accessable
	 */
	public View(Inventory inv, List<Grid> board, Player currPlayer,
			Set<Location> accessable) {
		myInventory = inv;
		this.accessable = accessable;
		this.board = board;
		this.currPlayer = currPlayer;
	}

	/**
	 * get a list of grids on board
	 * 
	 * @return a list of grids
	 */
	public List<Grid> getGrids() {
		return board;
	}

	/**
	 * get inventory
	 * 
	 * @return inventory
	 */
	public Inventory getInventory() {
		return myInventory;
	}

	/**
	 * get a list of location which can place tiles on
	 * 
	 * @return a list of location
	 */
	public Set<Location> getAccessable() {
		return accessable;
	}

	/**
	 * get current player
	 * 
	 * @return player
	 */
	public Player getCurrPlayer() {
		return currPlayer;
	}
	/**
	 * print the view as a string
	 * @return
	 */
	public String printView(){
		StringBuilder str = new StringBuilder();
		str.append("Board: \n");
		int newLine = 0;
		for(Grid g:board){
			++newLine;
			if(g.getTile()!=null)
				str.append(g.getTile().getLetter());
			else
				str.append(g.getName());
			if(newLine%15==0)
				str.append("\n");
		}
		str.append("inventory: "+myInventory.getTiles().size()+"\n");
		for(Tile t:myInventory.getTiles()){
			str.append(t.getLetter());
		}
		str.append("\n accessable: \n");
		for(Location l:accessable){
			str.append(l+"|");
		}
		System.out.println(str);
		return str.toString();
	}
}
