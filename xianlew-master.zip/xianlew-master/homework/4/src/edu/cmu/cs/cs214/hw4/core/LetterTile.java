/**
 * 
 */
package edu.cmu.cs.cs214.hw4.core;

/**
 * @author xianlewang
 * 
 */
public class LetterTile implements Tile {
	private String letter;
	private int score;

	/**
	 * Constructor to create a LetterTile with Letter "letter" and score "score"
	 * 
	 * @param letter
	 * @param score
	 */
	public LetterTile(String letter, int score) {
		this.letter = letter;
		this.score = score;
	}

	@Override
	public boolean isSpecial() {
		return false;
	}

	@Override
	public Effect getEffect() {
		return null;
	}

	@Override
	public String getLetter() {
		return letter;
	}

	@Override
	public int getScore() {
		return score;
	}

	@Override
	public Player getOwner() {
		return null;
	}

	@Override
	public void setOwner(Player owner) {		
	}

}
