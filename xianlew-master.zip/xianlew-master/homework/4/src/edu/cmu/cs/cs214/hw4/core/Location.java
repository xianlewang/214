/**
 * 
 */
package edu.cmu.cs.cs214.hw4.core;

/**
 * @author xianlewang location indicator on the board upper-left corner is the
 *         origin point
 */
public class Location {
	private int minX = 0;
	private int minY = 0;
	private int maxX = 14;
	private int maxY = 14;

	private int x;
	private int y;

	/**
	 * constructor a x,y location
	 * 
	 * @param x
	 * @param y
	 */
	public Location(int x, int y) {
		this.x = x;
		this.y = y;
	}

	/**
	 * return x
	 * 
	 * @return x
	 */
	public int getX() {
		return x;
	}

	/**
	 * return y
	 * 
	 * @return y
	 */
	public int getY() {
		return y;
	}

	/**
	 * return the upper location
	 * 
	 * @return upper location
	 */
	public Location up() {
		if (y <= minY)
			return null;
		return new Location(x, y - 1);
	}
	/**
	 * return the lower location
	 * @return location
	 */
	public Location down() {
		if (y >= maxY)
			return null;
		return new Location(x, y + 1);
	}
	/**
	 * return the left location
	 * @return location
	 */
	public Location left() {
		if (x <= minX)
			return null;
		return new Location(x - 1, y);
	}
	/**
	 * return the right location
	 * @return location
	 */
	public Location right() {
		if (x >= maxX)
			return null;
		return new Location(x + 1, y);
	}
	/**
	 * return index
	 * @return index
	 */
	public int toIndex(){
		return y*15+x;
	}
	
	public static Location iToLoc(int i){
		int y = i/15;
		int x = i%15;
		return new Location(x,y);
	}
	@Override
	public String toString() {
		return x + "," + y;
	}

	@Override
	public boolean equals(Object o) {
		if (o instanceof Location) {
			Location loc = (Location) o;
			if (x == loc.x && y == loc.y)
				return true;
		}
		return false;
	}

	@Override
	public int hashCode() {
		return x * 100 + y;
	}
	
	
}
