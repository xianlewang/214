/**
 * 
 */
package edu.cmu.cs.cs214.hw4.gui;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.border.MatteBorder;

/**
 * @author xianlewang
 *
 */
public class InvButton extends JButton{
	private int index;
	private String text;
	public InvButton(){
		this.setActionCommand("TILE");
		this.setPreferredSize(new Dimension(55,38));
		this.setFocusable(false);
	}
	@Override
	public void setText(String text){
		super.setText(text);
		MyColor.setColor(text, this);
		if(text==""){
			this.setVisible(false);
		}else{
			this.setVisible(true);
		}
	}
	@Override
	public void setEnabled(boolean b){
		super.setEnabled(b);
		this.setBorder(new MatteBorder(3,3,3,3,Color.MAGENTA));
		this.setBorderPainted(!b);

	}
	public int getIndex(){
		return index;
	}
	public void select(boolean b){
			this.setEnabled(!b);
	}
	public void setIndex(int index){
		this.index = index;
	}
}
