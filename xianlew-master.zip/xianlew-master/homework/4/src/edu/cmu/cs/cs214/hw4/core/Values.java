package edu.cmu.cs.cs214.hw4.core;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

/**
 * helper class to load the score of tiles
 * 
 * @author xianlewang
 * 
 */
public class Values {
	private static String fileName = "assets/values.txt";
	private static Map<String, Integer> map = null;

	private static void creatMap() {
		map = new HashMap<String, Integer>();
		FileInputStream inf = null;
		try {
			inf = new FileInputStream(fileName);
		} catch (FileNotFoundException e1) {
			System.out.println("wrong file");
		}
		BufferedReader inb = new BufferedReader(new InputStreamReader(inf));
		while (true) {
			String line = "";
			try {
				line = inb.readLine().trim();
				if (line == null || line.length() == 0)
					return;
				String letter = line.split("\t")[0];
				Integer score = Integer.valueOf(line.split("\t")[1]);
				map.put(letter, score);
			} catch (Exception e) {
				// System.out.println("error happens in Values.!!!");
				return;
			}
		}
	}

	/**
	 * get the score of the letter Tile
	 * 
	 * @param letter
	 * @return score
	 */
	public static int letterValue(String letter) {
		if (map == null) {
			creatMap();
		}
		if (letter == null || letter.length() != 1)
			return -1;
		return map.get(letter.toUpperCase());
	}

}
