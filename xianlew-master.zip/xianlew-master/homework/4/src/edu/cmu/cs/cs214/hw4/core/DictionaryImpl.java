package edu.cmu.cs.cs214.hw4.core;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class DictionaryImpl implements Dictionary {

	private Set<String> dict;
	/**
	 * constructor load the dictionary from the file
	 * @param fileName
	 */
	public DictionaryImpl(String fileName){
		dict = new HashSet<String>();
		FileInputStream inf = null;
		try {
			inf = new FileInputStream(fileName);
		} catch (FileNotFoundException e1) {
			System.out.println("wrong file");
		}
		BufferedReader inb = new BufferedReader(new InputStreamReader(inf));
		while(true){
			String line = "";
			try {
				line = inb.readLine();
				if(line==null||line.length()==0)
					return;
				line = line.trim();
				dict.add(line.trim());
			} catch (Exception e) {
				System.out.println("error happens in dict.!!!");
				e.printStackTrace();
				return;
			}
		}
	}
	@Override
	public boolean checkWord(String word) {
		return dict.contains(word.toLowerCase());
	}

}
