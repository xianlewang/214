/**
 * 
 */
package edu.cmu.cs.cs214.hw4.core;

import java.util.List;

/**
 * @author xianlewang
 * 
 */
public interface Board {
	/**
	 * get the grid at the location
	 * 
	 * @param loc
	 * @return grid
	 */
	public Grid get(Location loc);

	/**
	 * delete the tile at the location
	 * 
	 * @param loc
	 */
	public void delete(Location loc);

	/**
	 * place a tile at the location, and get the effect if there is a special
	 * tile on it
	 * 
	 * @param tile
	 * @param loc
	 * @return special Effect
	 */
	public Effect place(Tile tile, Location loc);

	/**
	 * get a list of grids on the board
	 * 
	 * @return a list of grids
	 */
	public List<Grid> getGrids();

	/**
	 * print the letter on the board, print - if empty
	 */
	public void printBoard();
}
