/**
 * hw4 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Oct. 7 2013
 */
package edu.cmu.cs.cs214.hw4.core;

import java.util.List;
import java.util.Set;

/**
 * @author xianlewang
 *
 */
public interface Game {

	/**
	 * get a set of location where allow to put tiles
	 * @return a set of location
	 */
	public Set<Location> getAccessLoc();
	/**
	 * place the tile to the location on board
	 * @param index the index of the tile in the inventory
	 * @param loc location
	 */
	public void placeTile(int index, Location loc);
	/**
	 * refresh the inventory
	 */
	public void exchange();
	/**
	 * purchase a new tile to the inventory
	 * @param tile
	 * @param cost
	 */
	public void purchase(Tile tile, int cost);
	/**
	 * pass a turn
	 * @return if this turn is played successfully
	 */
	public boolean pass();
	/**
	 * get the location of latest placed tile
	 * @return location
	 */
	public Location getCurrLoc();
	/**
	 * get the current player
	 * @return current player
	 */
	public Player getCurrPlayer();
	/**
	 * get the board
	 * @return board
	 */
	public Board getBoard();
	/**
	 * reverse the game order
	 */
	public void revOrder();
	/**
	 * get a list of player
	 * @return a list of player
	 */
	public List<Player> getAllPlayer();
}
