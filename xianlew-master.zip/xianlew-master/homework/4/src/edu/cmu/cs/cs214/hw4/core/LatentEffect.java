package edu.cmu.cs.cs214.hw4.core;
/**
 * marker interface of latent effect
 * @author xianlewang
 *
 */
public interface LatentEffect extends Effect{

}
