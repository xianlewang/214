package edu.cmu.cs.cs214.hw4.core;
/**
 * special effect to reverse the game order
 * @author xianlewang
 *
 */
public class ReverseOrderEffect implements ImmediateEffect {

	@Override
	public void doEffect(Game game) {
		game.revOrder();
	}

}
