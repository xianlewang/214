package edu.cmu.cs.cs214.hw4.core;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class BoardImpl implements Board {
	private int col = 15;
	private int row = 15;
	private List<Grid> grids = new ArrayList<Grid>();
	private String fileName = "assets/board.txt";
	
	/**
	 * Constructor will create a board according to the grids pattern in
	 * "assets/board.txt" file
	 */
	public BoardImpl() {
		for(int i = 0; i<col*row; ++i){
			grids.add(null);
		}
		FileInputStream inf = null;
		try {
			inf = new FileInputStream(fileName);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		BufferedReader inb = new BufferedReader(new InputStreamReader(inf));
		int numRow = 0;
		while (true) {
			String line = "";
			try {
				line = inb.readLine();
				if (line == null || line.length() == 0)
					return;
				
				String[] eles = line.split(",");
				for (int numCol = 0; numCol < eles.length; ++numCol) {
					String name = eles[numCol];
					Location loc1 = new Location(numCol, numRow);
					Location loc2 = new Location(col - 1 - numCol, numRow);
					Location loc3 = new Location(numCol, row - 1 - numRow);
					Location loc4 = new Location(col - 1 - numCol, row - 1
							- numRow);
					Grid grid1 = new Grid(name);
					Grid grid2 = new Grid(name);
					Grid grid3 = new Grid(name);
					Grid grid4 = new Grid(name);
					grids.set(locToIndex(loc1), grid1);
					grids.set(locToIndex(loc2), grid2);
					grids.set(locToIndex(loc3), grid3);
					grids.set(locToIndex(loc4), grid4);
				}
			} catch (Exception e) {
				System.out.println("error happens in board");
				e.printStackTrace();
				return;
			}
			++numRow;
		}
	}

	@Override
	public Grid get(Location loc) {
		return grids.get(locToIndex(loc));
	}
	
	@Override
	public void delete(Location loc) {
		grids.get(locToIndex(loc)).removeTile();
	}

	@Override
	public Effect place(Tile tile, Location loc) {
		Effect e = null;
		Grid g = grids.get(locToIndex(loc));
		if (g.getTile()!=null)
			throw new RuntimeException("cannot place here!");
		if (!tile.isSpecial())
			e = grids.get(locToIndex(loc)).getEffect();
		g.setTile(tile);
		return e;
	}

	@Override
	public List<Grid> getGrids() {
		return grids;
	}
	public void printBoard(){
		StringBuilder out = new StringBuilder();
		for(int y = 0; y<row; ++y){
			for(int x = 0; x<col; ++x){
				Tile t = get(new Location(x,y)).getTile();
				if(t == null)
					out.append("-");
				else
					out.append(t.getLetter());
			}
			out.append("\n");
		}
		System.out.println(out);
	}
	private int locToIndex(Location loc) {
		return loc.getY() * col + loc.getX();
	}
	
}
