package edu.cmu.cs.cs214.hw4.core;
/**
 * marker interface of immediate effect
 * @author xianlewang
 *
 */
public interface ImmediateEffect extends Effect {

}
