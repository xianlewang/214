/**
 * 
 */
package edu.cmu.cs.cs214.hw4.core;

/**
 * @author xianlewang
 * The Grid class
 */
public class Grid {
	private String name;
	private int wordScore = 1;
	private int letterScore = 1;
	private Tile tile;
	private Tile specTile;

	/**
	 * Constructor create a grid with Name and set its scores
	 * 
	 * @param name
	 */
	public Grid(String name) {
		this.name = name;
		setScores();
	}

	/**
	 * get the name
	 * 
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * get the letter tile;
	 * 
	 * @return the letter tile
	 */
	public Tile getTile() {
		return tile;
	}

	/**
	 * get the multiplier of the letter score
	 * 
	 * @return multiplier
	 */
	public int getLS() {
		return letterScore;
	}

	/**
	 * set the multiplier of the letter score
	 * 
	 * @param ls
	 *            multiplier
	 */
	public void setLS(int ls) {
		letterScore = ls;
	}

	/**
	 * get the multiplier of the word score
	 * 
	 * @return multiplier
	 */
	public int getWS() {
		return wordScore;
	}

	/**
	 * set the multiplier of the word score
	 * 
	 * @param ws
	 */
	public void setWS(int ws) {
		wordScore = ws;
	}

	/**
	 * get the special effect of the tile in the grid
	 * 
	 * @return special effect
	 */
	public Effect getEffect() {
		if (specTile != null)
			return specTile.getEffect();
		return null;
	}

	/**
	 * set a tile to the grid, can be both letterTile or SpecialTile
	 * 
	 * @param tile
	 */
	public void setTile(Tile tile) {
		if (tile.isSpecial()) {
			specTile = tile;
		} else {
			this.tile = tile;
		}
	}

	/**
	 * remove letterTile and specialTile
	 */
	public void removeTile() {
		tile = null;
		specTile = null;
	}
	/**
	 * clear the multipliers after use
	 */
	public void clearScore() {
		wordScore = 1;
		letterScore = 1;
	}

	private void setScores() {
		switch (name) {
		case "DL":
			letterScore = 2;
			break;
		case "TL":
			letterScore = 3;
			break;
		case "DW":
			wordScore = 2;
			break;
		case "TW":
			wordScore = 3;
			break;
		default:
			letterScore = 1;
			wordScore = 1;
			break;
		}
	}
	
	public Tile getSpecTile(){
		return specTile;
	}
}
