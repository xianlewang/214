/**
 * 
 */
package edu.cmu.cs.cs214.hw4.core;

import java.util.ArrayList;
import java.util.List;

/**
 * @author xianlewang
 * inventory class
 */
public class Inventory {
	private List<Tile> tiles;
	private List<Tile> specTiles;

	public Inventory() {
		tiles = Bag.pop(7);
		specTiles = new ArrayList<Tile>();
	}

	/**
	 * get a list of tiles, including special tiles.
	 * 
	 * @return a list of tiles
	 */
	public List<Tile> getTiles() {
		List<Tile> out = new ArrayList<Tile>();
		out.addAll(tiles);
		out.addAll(specTiles);
		return out;
	}

	/**
	 * add special tile to the inventory. If have more than 3 special
	 * tile,cannot add.
	 * 
	 * @param tile
	 */
	public void add(Tile tile) {
		if (tile.isSpecial() && specTiles.size() < 3) {
			specTiles.add(tile);
		}
	}

	/**
	 * get the tile at the index "number" the index starts from letterTile to
	 * special tile
	 * 
	 * @param number
	 *            the index( >=0)
	 * @return the tile
	 */
	public Tile pop(int number) {
		if (number < tiles.size())
			return tiles.remove(number);
		else if (number - tiles.size() < specTiles.size())
			return specTiles.remove(number - tiles.size());
		else
			return null;
	}

	/**
	 * refill the inventory
	 */
	public void refill() {
		if (tiles.size() < 7) {
			List<Tile> ts = Bag.pop(7 - tiles.size());
			for (Tile t : ts) {
				tiles.add(t);
			}
		}
	}

	/**
	 * return the size
	 * 
	 * @return size
	 */
	public int size() {
		return tiles.size() + specTiles.size();
	}

}
