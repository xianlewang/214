/**
 * 
 */
package edu.cmu.cs.cs214.hw4.core;

/**
 * @author xianlewang Tile interface
 */
public interface Tile {
	/**
	 * check if it is special tile
	 * 
	 * @return true if special
	 */
	public boolean isSpecial();

	/**
	 * get the effect
	 * 
	 * @return the effect
	 */
	public Effect getEffect();

	/**
	 * get the letter
	 * 
	 * @return letter
	 */
	public String getLetter();

	/**
	 * get the score
	 * 
	 * @return score
	 */
	public int getScore();
	
	/**
	 * get the owner
	 * @return  owner player
	 */
	public Player getOwner();
	
	/**
	 * set the owner
	 * @return
	 */
	public void setOwner(Player owner);
	
}
