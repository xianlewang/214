/**
 * 
 */
package edu.cmu.cs.cs214.hw4.core;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author xianlewang
 * 
 */
public class GameImpl implements Game {
	private Player currPlayer;
	private List<Player> players = new ArrayList<Player>(0);
	private int order = 1;
	// private List<LatentEffect> latentEffects = new
	// ArrayList<LatentEffect>(0);
	private Board board;
	private Dictionary dict;
	private Location currLoc;
	private List<Location> playHistory;
	private int dirFlag;// 1: onRow -1: onCol 0 : notValid
	private int col = 15;
	private int row = 15;

	public GameImpl(int numPlayer) {
		for (int i = 0; i < numPlayer; ++i) {
			players.add(new PlayerImpl(i));
		}
		currPlayer = players.get(0);
		dict = new DictionaryImpl("assets/words.txt");
		board = new BoardImpl();
		currLoc = new Location(row / 2, col / 2);
		playHistory = new ArrayList<Location>();
	}

	// @Override
	// public View getView() {
	// return new View(currPlayer.getInventory(), board.getGrids(), currPlayer,
	// accessableLoc());
	// }

	@Override
	public void exchange() {
		currPlayer.changeInv();
	}

	@Override
	public void purchase(Tile tile, int cost) {
		if (currPlayer.getScore() < cost) {
			System.out.println("not enough score");
			return;
		}
		tile.setOwner(currPlayer);
		currPlayer.setScore(currPlayer.getScore() - cost);
		currPlayer.addTile(tile);
	}

	@Override
	public boolean pass() {
		Boolean result = turnResult();
		if (result) {
			for (Location loc : playHistory) {
				board.get(loc).clearScore();
			}
		}else{
			for(Location l:playHistory){
				board.get(l).removeTile();
			}
		}
		currPlayer.getInventory().refill();
		toNextPlayer();
		dirFlag = 0;
		playHistory = new ArrayList<Location>();
		return result;
	}

	@Override
	public void placeTile(int index, Location loc) {
		Tile t = currPlayer.popTile(index);
		if (t.isSpecial()) {
			board.place(t, loc);
			return;
		}
		currLoc = loc;
		playHistory.add(loc);
		if (playHistory.size() == 2) {
			if (playHistory.get(0).getX() == playHistory.get(1).getX())
				dirFlag = -1;
			else if (playHistory.get(0).getY() == playHistory.get(1).getY())
				dirFlag = 1;
		}
		Effect e = board.place(t, loc);
		if (e != null)
			e.doEffect(this);
	}

	@Override
	public Location getCurrLoc() {
		return currLoc;
	}

	@Override
	public Player getCurrPlayer() {
		return currPlayer;
	}

	@Override
	public Board getBoard() {
		return board;
	}

	@Override
	public void revOrder() {
		this.order = -1 * order;
	}

	private Player toNextPlayer() {

		int newI = (players.indexOf(currPlayer) + order) % players.size();
		currPlayer = players.get(newI);
		return currPlayer;
	}

	/**
	 * evaluate the result of this turn. if valid play, add up the score if not
	 * valid, return false
	 * 
	 * @return true if the play is valid
	 */
	private boolean turnResult() {
		int turnScore = 0;
		if (dirFlag == 1) {
			int rowS = checkRow(playHistory.get(0));
			if (rowS == -1) {
				return false;
			} else {
				turnScore += rowS;
			}
			for (Location loc : playHistory) {
				int colS = checkCol(loc);
				if (colS == -1) {
					return false;
				} else {
					turnScore += colS;
				}
			}
		} else if (dirFlag == -1) {
			int colS = checkCol(playHistory.get(0));
			if (colS == -1) {
				return false;
			} else {
				turnScore += colS;
			}
			for (Location loc : playHistory) {
				int rowS = checkRow(loc);
				if (rowS == -1) {
					return false;
				} else {
					turnScore += rowS;
				}
			}
		}else{
			return false;
		}
		currPlayer.setScore(currPlayer.getScore() + turnScore);
		return true;
	}

	private int checkCol(Location loc) {
		int wordS = 0;
		int wordM = 1;
		StringBuilder tmpStr = new StringBuilder();
		tmpStr.append(board.get(loc).getTile().getLetter());
		Location upEnd = loc;
		Location downEnd = loc;
		// goint up from loc
		while (upEnd.up() != null && board.get(upEnd.up()).getTile() != null) {
			upEnd = upEnd.up();
			tmpStr.insert(0, board.get(upEnd).getTile().getLetter());
		}
		// goint down from loc
		while (downEnd.down() != null
				&& board.get(downEnd.down()).getTile() != null) {
			downEnd = downEnd.down();
			tmpStr.append(board.get(downEnd).getTile().getLetter());
		}
		if (upEnd.equals(downEnd)) {
			return 0;
		}
		// System.out.println("checking: " + tmpStr + " U/D: " + upEnd + "/"
		// + downEnd);
		if (dict.checkWord(tmpStr.toString())) {
			Location tmp = upEnd;
			int step = downEnd.getY() - upEnd.getY();
			for (int i = 0; i <= step; ++i) {
				wordS += (board.get(tmp).getTile().getScore() * board.get(tmp)
						.getLS());
				wordM *= board.get(tmp).getWS();
				tmp = tmp.down();
			}
			// System.out.println("wordScore = " + wordS + " / milt: " + wordM);
			return wordS * wordM;
		}
		return -1;
	}

	private int checkRow(Location loc) {
		int wordS = 0;
		int wordM = 1;
		StringBuilder tmpStr = new StringBuilder();
		tmpStr.append(board.get(loc).getTile().getLetter());
		Location leftEnd = loc;
		Location rightEnd = loc;
		// goint up from loc
		while (leftEnd.left() != null
				&& board.get(leftEnd.left()).getTile() != null) {
			leftEnd = leftEnd.left();
			tmpStr.insert(0, board.get(leftEnd).getTile().getLetter());
		}
		// goint down from loc
		while (rightEnd.right() != null
				&& board.get(rightEnd.right()).getTile() != null) {
			rightEnd = rightEnd.right();
			tmpStr.append(board.get(rightEnd).getTile().getLetter());
		}
		if (leftEnd.equals(rightEnd)) {
			return 0;
		}
		// System.out.println("checking: " + tmpStr + " L/R: " + leftEnd + "/"
		// + rightEnd);
		if (dict.checkWord(tmpStr.toString())) {
			Location tmp = leftEnd;
			int step = rightEnd.getX() - leftEnd.getX();
			for (int i = 0; i <= step; ++i) {
				wordS += (board.get(tmp).getTile().getScore() * board.get(tmp)
						.getLS());
				wordM *= board.get(tmp).getWS();
				tmp = tmp.right();
			}
			// System.out.println("wordScore = " + wordS + " / milt: " + wordM);
			return wordS * wordM;
		}
		return -1;
	}

	@Override
	public Set<Location> getAccessLoc() {
		Set<Location> aL = new HashSet<Location>();
		if (playHistory.size() == 0) {
			for (int y = 0; y < row; ++y) {
				for (int x = 0; x < col; ++x) {
					Location l = new Location(x, y);
					if (board.get(l).getTile() == null && nearTile(l)) {
						aL.add(l);
					}
				}
			}
			if (aL.size() == 0)
				aL.add(new Location(col / 2, row / 2));
		} else if (playHistory.size() == 1) {
			Location tmp = playHistory.get(0);
			if (tmp.up() != null && board.get(tmp.up()).getTile() == null)
				aL.add(tmp.up());
			if (tmp.down() != null && board.get(tmp.down()).getTile() == null)
				aL.add(tmp.down());
			if (tmp.left() != null && board.get(tmp.left()).getTile() == null)
				aL.add(tmp.left());
			if (tmp.right() != null && board.get(tmp.right()).getTile() == null)
				aL.add(tmp.right());
			if ((tmp.up() != null && board.get(tmp.up()).getTile() != null)
					|| (tmp.down() != null && board.get(tmp.down()).getTile() != null)) {
				int x = playHistory.get(0).getX();
				for (int y = 0; y < col; ++y) {
					Location tmp1 = new Location(x, y);
					if (board.get(tmp1).getTile() == null)
						aL.add(tmp1);
				}
			}
			if ((tmp.left() != null && board.get(tmp.left()).getTile() != null)
					|| (tmp.right() != null && board.get(tmp.right()).getTile() != null)) {
				int y = playHistory.get(0).getY();
				for (int x = 0; x < col; ++x) {
					Location tmp2 = new Location(x, y);
					if (board.get(tmp2).getTile() == null)
						aL.add(tmp2);
				}
			}
		} else {
			if (dirFlag == 1) {
				int y = playHistory.get(0).getY();
				for (int x = 0; x < col; ++x) {
					Location tmp = new Location(x, y);
					if (board.get(tmp).getTile() == null)
						aL.add(tmp);
				}
			} else if (dirFlag == -1) {
				int x = playHistory.get(0).getX();
				for (int y = 0; y < col; ++y) {
					Location tmp = new Location(x, y);
					if (board.get(tmp).getTile() == null)
						aL.add(tmp);
				}
			}

		}
		return aL;
	}

	private boolean nearTile(Location loc) {
		return (loc.down() != null && board.get(loc.down()).getTile() != null)
				|| (loc.up() != null && board.get(loc.up()).getTile() != null)
				|| (loc.left() != null && board.get(loc.left()).getTile() != null)
				|| (loc.right() != null && board.get(loc.right()).getTile() != null);
	}

	@Override
	public List<Player> getAllPlayer() {
		return players;
	}

}