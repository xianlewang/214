package edu.cmu.cs.cs214.hw4.core;

public class DoubleLetterScoreEffect implements ImmediateEffect {
	/**
	 * Special effect to double the letter score of the tile on it, it will
	 * change the gird's field
	 */
	@Override
	public void doEffect(Game game) {
		Board board = game.getBoard();
		Grid currGrid = board.get(game.getCurrLoc());
		currGrid.setLS(currGrid.getLS() * 2);
	}

}
