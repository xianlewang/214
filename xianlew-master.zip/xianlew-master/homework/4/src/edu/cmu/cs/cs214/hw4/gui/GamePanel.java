/**
 * 
 */
package edu.cmu.cs.cs214.hw4.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.border.MatteBorder;

import edu.cmu.cs.cs214.hw4.core.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author xianlewang
 * main Game UI 
 */
public class GamePanel implements ActionListener {
	private JFrame frame;
	private JPanel invPanel;
	private JPanel boardPanel;
	private JPanel controlPanel;
	private Game game;
	private GridButton[] grids;
	private int numGrid = 225;
	private InvButton selectedTile = null;
	private String helpStr = "";
	private JTextArea helpText;
	/**
	 * set up main game UI
	 * @param game
	 */
	public GamePanel(Game game) {
		this.game = game;
		frame = new JFrame("15214 - Scrabble with Stuff");
		frame.setSize(1200, 800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel pane = new JPanel();
		BorderLayout paneLayout = new BorderLayout();
		pane.setLayout(paneLayout);

		// set model
		UIManager.put("Button.disabledText", Color.LIGHT_GRAY);
		grids = new GridButton[numGrid];
		for (int i = 0; i < numGrid; ++i) {
			grids[i] = new GridButton(i);
			grids[i].addActionListener(this);
		}
		// set grids
		boardPanel = new JPanel(new GridLayout(15, 15, 5, 10));
		for (GridButton b : grids) {
			boardPanel.add(b);
		}
		setBoard();
		pane.add(boardPanel, BorderLayout.CENTER);
		// set inventory
		JPanel firstP = new JPanel();
		JLabel invL = new JLabel("Your Inventory:  ");
		invL.setFont(new Font("ITALIC", 1, 20));
		firstP.add(invL);
		invPanel = new JPanel();
		for (int i = 0; i < 10; ++i) {
			InvButton b = new InvButton();
			b.addActionListener(this);
			invPanel.add(b);
		}
		setInventory();
		firstP.add(invPanel);
		pane.add(firstP, BorderLayout.PAGE_START);
		// set control panel
		controlPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		controlPanel.setPreferredSize(new Dimension(210, 0));
		pane.add(controlPanel, BorderLayout.EAST);
		JButton passButton = new JButton("PASS");
		passButton.setBackground(new Color(160, 160, 220));
		passButton.setFont(new Font("ITALIC", 1, 20));
		passButton.addActionListener(this);
		passButton.setActionCommand("PASS");

		// set exit
		JButton end = new JButton("End Game!");
		end.setBackground(new Color(160, 160, 220));
		end.setFont(new Font("ITALIC", 1, 20));
		end.addActionListener(this);
		end.setActionCommand("END");
		
		JPanel bu = new JPanel(new GridLayout(6,1,0,20));
		bu.add(passButton);
		bu.add(end);
		controlPanel.add(bu);
		// set purchase
		JPanel purchasePane = new JPanel(new GridLayout(4, 1, 0, 0));
		JLabel purchase = new JLabel("Purchase:");
		purchase.setFont(new Font("ITALIC", 1, 15));
		bu.add(purchase);
		JButton doubleLetterScoreTile = new JButton("Double Score | $10");
		doubleLetterScoreTile.setBackground(new Color(160, 160, 220));
		doubleLetterScoreTile.addActionListener(this);
		doubleLetterScoreTile.setActionCommand("DOUBLE_L_SCORE");
		bu.add(doubleLetterScoreTile);
		JButton negScoreTile = new JButton("Negative Score | $10");
		negScoreTile.setBackground(new Color(160, 160, 220));
		negScoreTile.addActionListener(this);
		negScoreTile.setActionCommand("NEGATIVE_SCORE");
		bu.add(negScoreTile);
		JButton revOrderTile = new JButton("Reverse Order | $10");
		revOrderTile.setBackground(new Color(160, 160, 220));
		revOrderTile.addActionListener(this);
		revOrderTile.setActionCommand("REVERSE_ORDER");
		bu.add(revOrderTile);
		purchasePane.setBorder(new MatteBorder(3, 3, 3, 3, Color.black));

		// set help
		helpText = new JTextArea();
		helpText.setBackground(Color.white);
		helpText.setPreferredSize(new Dimension(190, 300));
		helpText.setBorder(new MatteBorder(3, 3, 3, 3, Color.black));
		helpText.setMargin(new Insets(10, 10, 10, 10));
		helpText.setFont(new Font("ITALIC", 1, 12));
		helpText.setEditable(false);
		helpText.setAutoscrolls(true);
		helpText.setLineWrap(true);
		helpText.setWrapStyleWord(true);
		setHelpInfo();
		JLabel helpLabel = new JLabel("Help Board");
		controlPanel.add(helpText);
		frame.setContentPane(pane);
		frame.setVisible(true);
	}

	

	private void setInventory() {
		int index = 0;
		for (Tile t : game.getCurrPlayer().getInventory().getTiles()) {
			InvButton it = (InvButton) invPanel.getComponent(index);
			it.setIndex(index);
			it.setText(t.getLetter());
			it.setEnabled(true);
			++index;
		}
		while (index < 10) {
			InvButton it = (InvButton) invPanel.getComponent(index);
			it.setIndex(index);
			it.setText("");
			it.setEnabled(false);
			++index;
		}
		invPanel.repaint();
	}

	private void setBoard() {
		List<Grid> gs = game.getBoard().getGrids();
		if (gs.size() == 0) {
			endGame();
		}
		for (int i = 0; i < numGrid; ++i) {
			String text = null;
			if (gs.get(i).getTile() != null)
				text = gs.get(i).getTile().getLetter();
			else if (gs.get(i).getSpecTile() != null
					&& game.getCurrPlayer().equals(gs.get(i).getSpecTile().getOwner())) {
				text = gs.get(i).getSpecTile().getLetter();
			} else {
				text = gs.get(i).getName();
			}
			grids[i].setText(text);
			grids[i].setEnabled(false);
		}
		for (Location loc : game.getAccessLoc()) {
			grids[loc.toIndex()].setEnabled(true);
		}
	}

	private void endGame() {
		game.pass();
		List<Player> allPlayer = game.getAllPlayer();
		Collections.sort(allPlayer, new Comparator<Player>() {
			@Override
			public int compare(Player o1, Player o2) {
				return ((Player) o2).getScore() - ((Player) o1).getScore();
			}
		});
		StringBuilder info = new StringBuilder();
		info.append("Game over!\nResult:\n");
		for (int i = 0; i < allPlayer.size(); ++i) {
			info.append("No." + i + "  Player: " + allPlayer.get(i)
					+ " (score: " + allPlayer.get(i).getScore() + ")\n");
		}
		JOptionPane.showMessageDialog(null, info.toString(), "Result",
				JOptionPane.INFORMATION_MESSAGE);
		frame.dispose();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		helpStr = "";
		switch (command) {
		case "GRID":
			clickGrid(Location.iToLoc(((GridButton) e.getSource()).getIndex()));
			break;
		case "TILE":
			clickTile((InvButton) e.getSource());
			break;
		case "PASS":
			pass();
			break;
		case "DOUBLE_L_SCORE":
			purchase(new DoubleLetterScoreTile());
			break;
		case "NEGATIVE_SCORE":
			purchase(new NegativeScoreTile());
			break;
		case "REVERSE_ORDER":
			purchase(new ReverseOrderTile());
			break;
		case "END":
			endGame();
			break;
		}
		setHelpInfo();

	}

	private void purchase(Tile t) {
		if (game.getCurrPlayer().getScore() < t.getScore()) {
			helpStr = "Money is not enough!";
			return;// warning
		} else {
			game.purchase(t, t.getScore());
			// confirm
			setInventory();
			pass();
		}
	}

	private void clickGrid(Location loc) {
		if (selectedTile != null) {
			game.placeTile(selectedTile.getIndex(), loc);
			selectedTile.select(false);
			setInventory();
		}else{
			helpStr = "Please select a inventory tile first!\n";
		}
		selectedTile = null;
		setBoard();
	}

	private void clickTile(InvButton i) {
		if (selectedTile != null)
			selectedTile.select(false);
		selectedTile = i;
		i.select(true);
	}



	private void setHelpInfo() {
		StringBuilder str = new StringBuilder();
		str.append("Current Player: " + game.getCurrPlayer()
				+ "\nCurrent Score: " + game.getCurrPlayer().getScore()
				+ "\n\n");
		str.append(helpStr);
		helpText.setText(str.toString());
	}

	private void pass() {
		System.out.println("in pass");
		Player tmp = game.getCurrPlayer();
		selectedTile = null;
		Boolean done = game.pass();
		StringBuilder info = new StringBuilder();
		if (done) {
			info.append("This turn finished!\nPlayer " + tmp
					+ " 's current score: " + tmp.getScore()
					+ ".\nNext Player: " + game.getCurrPlayer());
			JOptionPane.showMessageDialog(null, info.toString(), "Info",
					JOptionPane.INFORMATION_MESSAGE);
		} else {
			info.append("Invalid words!\nTurn failed, tiles removed!\nPlayer: "
					+ tmp
					+ "\ncurrent score: "
					+ tmp.getScore()
					+ "\nNext Player: " + game.getCurrPlayer());
			JOptionPane.showMessageDialog(null, info.toString(), "Info",
					JOptionPane.WARNING_MESSAGE);
		}

		setBoard();
		setInventory();
	}
}
