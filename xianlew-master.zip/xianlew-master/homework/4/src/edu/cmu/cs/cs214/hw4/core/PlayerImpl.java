package edu.cmu.cs.cs214.hw4.core;
/**
 * player class
 * @author xianlewang
 *
 */
public class PlayerImpl implements Player {

	private Inventory myInv;
	private int score;
	private String name;
	public PlayerImpl(int i){
		myInv = new Inventory();
		name = i+"";
	}
	@Override
	public Inventory getInventory() {
		return myInv;
	}

	@Override
	public void addTile(Tile tile) {
		myInv.add(tile);
	}

	@Override
	public Tile popTile(int index) {
		return myInv.pop(index);
	}

	@Override
	public int getScore() {
		return score;
	}

	@Override
	public void setScore(int score) {
		this.score = score;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public void changeInv() {
		myInv = new Inventory();
	}
	@Override
	public String toString(){
		return name;
	}

}
