/**
 * 
 */
package edu.cmu.cs.cs214.hw4.core;

/**
 * @author xianlewang
 * 
 */
public interface Dictionary {
	/**
	 * validate the word
	 * 
	 * @param word
	 * @return validation of the word
	 */
	public boolean checkWord(String word);
}
