package edu.cmu.cs.cs214.hw4.core;
/**
 * marker interface of special tile
 * @author xianlewang
 *
 */
public interface SpecialTile extends Tile{
	
}
