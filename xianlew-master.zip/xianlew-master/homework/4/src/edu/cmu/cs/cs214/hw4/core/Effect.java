/**
 * 
 */
package edu.cmu.cs.cs214.hw4.core;

/**
 * @author xianlewang
 *	Effect interface
 */
public interface Effect {
	/**
	 * make effect on the game
	 * @param game
	 */
	public void doEffect(Game game);
}
