package edu.cmu.cs.cs214.hw4.core;
/**
 * a special tile to double the letter score
 * @author xianlewang
 *
 */
public class DoubleLetterScoreTile implements SpecialTile{
	private int cost = 10;
	private Effect effect;
	private Player owner;
	public DoubleLetterScoreTile(){
		effect = new DoubleLetterScoreEffect();
	}

	@Override
	public boolean isSpecial() {
		return true;
	}

	@Override
	public Effect getEffect() {
		return effect;
	}

	@Override
	public String getLetter() {
		return "DLT";
	}

	@Override
	public int getScore() {
		return cost;
	}
	@Override
	public Player getOwner() {
		return owner;
	}
	@Override
	public void setOwner(Player owner) {
		this.owner = owner;
	}
}
