package edu.cmu.cs.cs214.hw4.core;
/**
 * special effect class to set the score to negative
 * @author xianlewang
 *
 */
public class NegativeScoreEffect implements ImmediateEffect {

	@Override
	public void doEffect(Game game) {
		Board board = game.getBoard();
		Grid currGrid = board.get(game.getCurrLoc());
		currGrid.setWS(currGrid.getWS()*(-1));
	}

}
