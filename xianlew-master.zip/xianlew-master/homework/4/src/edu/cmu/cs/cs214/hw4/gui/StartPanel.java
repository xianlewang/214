package edu.cmu.cs.cs214.hw4.gui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import edu.cmu.cs.cs214.hw4.core.Game;
import edu.cmu.cs.cs214.hw4.core.GameImpl;
/**
 * Game initial UI
 * @author xianlewang
 *
 */
public class StartPanel implements ActionListener {
	private List<String> names = new ArrayList<String>();
	private Game game;
	private JTextField pname;
	private String output = "";
	private JTextArea list ;
	private JFrame frame;
	/**
	 * UI to start game
	 */
	public StartPanel() {
		frame = new JFrame("Starting");
		frame.setSize(500, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel iniP = new JPanel(new BorderLayout());
		JPanel line1 = new JPanel();
		JButton addB = new JButton("Add Player");
		addB.addActionListener(this);
		addB.setActionCommand("ADD");
		JButton startB = new JButton("Start Game");
		startB.setActionCommand("START");
		startB.addActionListener(this);
		pname = new JTextField(10);
		line1.add(pname);
		line1.add(addB);
		line1.add(startB);
		list = new JTextArea(10, 10);
		iniP.add(line1, BorderLayout.NORTH);
		iniP.add(list, BorderLayout.CENTER);
		frame.setContentPane(iniP);
		frame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		switch (command) {
		case "ADD":
			String name = pname.getText();
			names.add(name);
			output += name + "\n";
			list.setText(output);
			pname.setText("");
			break;
		case "START":
			if(names.size()<=0){
				list.setText("Please add a player!\n");
				break;
			}
			game = new GameImpl(names.size());
			frame.dispose();
			for(int i=0; i<names.size();++i){
				game.getAllPlayer().get(i).setName(names.get(i));
			}
			new GamePanel(game);
			break;

		}

	}
	public static void main(String[] args) {
		new StartPanel();
	}
}
