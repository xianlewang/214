package edu.cmu.cs.cs214.hw4.gui;

import java.awt.Color;
import java.awt.Font;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JComponent;

public class MyColor {
	private static Map<String, Color> colorMap;
	private static void ini(){
		colorMap = new HashMap<String, Color>();
		colorMap.put("DL", Color.yellow);
		colorMap.put("TL", Color.yellow);
		colorMap.put("DW", Color.CYAN);
		colorMap.put("TW", Color.CYAN);
		colorMap.put(" ", Color.LIGHT_GRAY);
	}
	public static void setColor(String text, JComponent component){
		if(colorMap==null){
			ini();
		}
		component.setFont(new Font("ITALIC",1,15));
		component.setForeground(Color.LIGHT_GRAY);

		if(colorMap.containsKey(text)){
			component.setBackground((colorMap.get(text)));
		}else{
			component.setBackground(new Color(0,20,150));
		}

	}
}
