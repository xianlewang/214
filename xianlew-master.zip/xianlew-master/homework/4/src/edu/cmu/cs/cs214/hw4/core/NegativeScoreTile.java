package edu.cmu.cs.cs214.hw4.core;
/**
 * special tile class
 * @author xianlewang
 *
 */
public class NegativeScoreTile implements SpecialTile{
	private int cost = 10;
	private Effect effect;
	private Player owner;
	public NegativeScoreTile(){
		effect = new NegativeScoreEffect();
	}
	@Override
	public boolean isSpecial() {
		return true;
	}

	@Override
	public Effect getEffect() {
		return effect;
	}

	@Override
	public String getLetter() {
		return "NST";
	}

	@Override
	public int getScore() {
		return cost;
	}
	@Override
	public Player getOwner() {
		return owner;
	}
	@Override
	public void setOwner(Player owner) {
		this.owner = owner;
	}

}
