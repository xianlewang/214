Place any non-code-related assets that your program uses in this directory.
Examples of such assets include image files, text files, etc. used by your 
program.

This directory already contains one asset you may use in your implementation. 
If your program uses any additional assets, please list them below:

    - words.txt
        A text file containing 64,000 lower-case words.
    - values.txt
	A text file containing the Letter-score map of all the letters
    - board.txt
	A text file using letters to represent the pattern of the board layout

----------------------------------------------------------------------------------
main() method is located at /src/edu/cmu/cs/cs214/hw4/gui/StartPanel.java

To play the game:
1. Add the players' name in the start window. And press "Start Game" button.
2. At the main game UI, select a tile in your Inventory, and select a location on the board, then the tile will be placed on the location.
3. You can only place the tile on location which is highlighted by orange border.
4. You can purchase a special tile if you have enough money (scores). After purchasing, this turn will be passed. 
5. To pass your turn, press "Pass" button; to end the game, press "End Game" button. The result of this turn/game will show up.
