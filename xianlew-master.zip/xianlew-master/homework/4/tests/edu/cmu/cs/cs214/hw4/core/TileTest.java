package edu.cmu.cs.cs214.hw4.core;

import static org.junit.Assert.*;

import org.junit.Test;

public class TileTest {

	@Test
	public void testLetterTile() {
		Tile t = new LetterTile("A", 2);
		assertFalse(t.isSpecial());
		assertNull(t.getEffect());
		assertEquals("A",t.getLetter());
		assertEquals(2,t.getScore());
	}
	@Test
	public void testNegScoreTile() {
		Tile st = new NegativeScoreTile();
		Tile t = new LetterTile("A", 2);
		assertFalse(t.isSpecial());
		assertTrue(st.isSpecial());
	}
	@Test
	public void testDoubleScoreTile() {
		Tile st = new DoubleLetterScoreTile();
		Tile t = new LetterTile("A", 2);
		assertFalse(t.isSpecial());
		assertTrue(st.isSpecial());
	}
	@Test
	public void testRevOrderTile() {
		Tile st = new ReverseOrderTile();
		Tile t = new LetterTile("A", 2);
		assertFalse(t.isSpecial());
		assertTrue(st.isSpecial());
	}
}
