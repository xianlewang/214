package edu.cmu.cs.cs214.hw4.core;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class LocationTest {
	private Location loc;
	@Before
	public void setUp(){
		loc = new Location(0,9);
	}
	@Test
	public void test() {
		assertEquals("0.9",loc.toString());
		assertEquals(0,loc.getX());
		assertEquals("1.9",loc.right().toString());
		assertEquals("0.10",loc.down().toString());
		assertNull(loc.left());
	}

}
