package edu.cmu.cs.cs214.hw4.core;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class BoardTest {
    private Board board;
    private int col = 15;
	private int row = 15;
    @Before
    public void setUp(){
    	board = new BoardImpl();
    	List<Tile> tiles = Bag.pop(10);
    }
	@Test
	public void testBoard() {
		assertTrue(board!=null);
		assertEquals(225,board.getGrids().size());
	}
	@Test
	public void testLocToIndex() {
		Location loc = new Location(10,1);
		assertEquals(25,loc.getY() * col + loc.getX());
	}
	@Test
	public void textGet(){
		assertEquals("DW", board.get(new Location(10,4)).getName());
		assertEquals("TL", board.get(new Location(5,9)).getName());
	}
	@Test
	public void textPlace(){
		board.place(new LetterTile("C",10), new Location(10,4));
		assertEquals(10, board.get(new Location(10,4)).getTile().getScore());
	}
	@Test
	public void textDelete(){
		board.place(new LetterTile("C",10), new Location(10,5));
		board.delete(new Location(10,5));
		assertNull(board.get(new Location(10,5)).getTile());
	}

}
