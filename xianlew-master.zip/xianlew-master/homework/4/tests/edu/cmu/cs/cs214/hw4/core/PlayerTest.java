package edu.cmu.cs.cs214.hw4.core;

import static org.junit.Assert.*;

import org.junit.Test;

public class PlayerTest {
	@Test
	public void testGetInv() {
		Player p = new PlayerImpl(1);
		assertEquals(7,p.getInventory().size());
	}
	@Test
	public void testAdd() {
		Player p = new PlayerImpl(1);
		p.addTile(new LetterTile("A",2));
		assertEquals(7,p.getInventory().size());
		p.addTile(new DoubleLetterScoreTile());
		assertEquals(8,p.getInventory().size());
	}
	@Test
	public void testPop() {
		Player p = new PlayerImpl(1);
		p.popTile(0);
		assertEquals(6,p.getInventory().size());
		p.addTile(new DoubleLetterScoreTile());
		assertEquals(7,p.getInventory().size());
		assertTrue(p.popTile(6).isSpecial());
	}
	@Test
	public void testScore() {
		Player p = new PlayerImpl(1);
		p.setScore(10);
		assertEquals(10,p.getScore());
	}
}
