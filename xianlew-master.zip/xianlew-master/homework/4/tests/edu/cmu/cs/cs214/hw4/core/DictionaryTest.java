package edu.cmu.cs.cs214.hw4.core;

import static org.junit.Assert.*;

import org.junit.Test;

public class DictionaryTest {
	private DictionaryImpl dict;
	@Test
	public void test() {
		dict = new DictionaryImpl("assets/words.txt");
		assertTrue(dict.checkWord("abate"));
		assertFalse(dict.checkWord("abte"));
		
	}

}
