package edu.cmu.cs.cs214.hw4.core;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class BagTest {

	@Test
	public void testPop(){
		assertFalse(Bag.pop(10)==null);
	}

}
