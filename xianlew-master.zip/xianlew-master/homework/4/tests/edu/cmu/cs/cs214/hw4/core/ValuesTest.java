package edu.cmu.cs.cs214.hw4.core;

import static org.junit.Assert.*;

import org.junit.Test;

public class ValuesTest {
	@Test
	public void test() {
		assertEquals(1,Values.letterValue("A"));
		assertEquals(-1,Values.letterValue("WW"));
		assertEquals(-1,Values.letterValue(""));
		
	}

}
