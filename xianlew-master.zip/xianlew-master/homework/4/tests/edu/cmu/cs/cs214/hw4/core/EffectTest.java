package edu.cmu.cs.cs214.hw4.core;

import static org.junit.Assert.*;

import org.junit.Test;

public class EffectTest {

	@Test
	public void testNegScore() {
		Effect e = new NegativeScoreEffect();
		Game g = new GameImpl(1);
		e.doEffect(g);
		assertTrue(g.getBoard().get(new Location(8,8)).getWS()<0);
	}
	@Test
	public void testDouScore() {
		Effect e = new DoubleLetterScoreEffect();
		Game g = new GameImpl(1);
		e.doEffect(g);
		assertEquals(4,g.getBoard().get(new Location(8,8)).getLS());
	}
	@Test
	public void testRevOrder() {
		Effect e = new ReverseOrderEffect();
		Game g = new GameImpl(3);
		Player p = g.getCurrPlayer();
		g.pass();
		e.doEffect(g);
		g.pass();
		assertEquals(p,g.getCurrPlayer());
	}
	
}
