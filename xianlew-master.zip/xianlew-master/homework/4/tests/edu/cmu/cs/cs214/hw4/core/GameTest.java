package edu.cmu.cs.cs214.hw4.core;

import static org.junit.Assert.*;

import org.junit.Test;
/**
 * some of the test is done by check the printout.
 * @author xianlewang
 *
 */
public class GameTest {
	
	@Test
	public void test() {
		Game game = new GameImpl(3);
		assertTrue(game!=null);
	}
	
	@Test
	public void testPlayer() {
		Game game = new GameImpl(3);
		Player p1= game.getCurrPlayer();
		game.pass();
		assertTrue(game.getCurrPlayer()!=p1);
	}
	@Test
	public void testPurchase(){
		Game game = new GameImpl(3);
		Player p1 = game.getCurrPlayer();//p1
		game.pass();//p2
		game.purchase(new ReverseOrderTile(), 0);//p3
		game.pass();//p1
		game.pass();//p2
		game.placeTile(7, new Location(8,8));//p2
		game.placeTile(0, new Location(8,8));//p2
		game.pass();//p1
		assertEquals(p1,game.getCurrPlayer());
	}
	
	@Test
	public void testPlace1(){
		Game game = new GameImpl(1);
		game.placeTile(0, new Location(8,0));
		game.placeTile(0, new Location(8,1));
		game.placeTile(0, new Location(8,2));
		game.placeTile(0, new Location(8,3));
		game.placeTile(0, new Location(8,4));
		game.pass();
	}
	@Test
	public void testPlace2(){
		Game game = new GameImpl(1);
		game.placeTile(0, new Location(1,2));
		game.placeTile(0, new Location(5,2));
		game.placeTile(0, new Location(2,2));
		game.placeTile(0, new Location(3,2));
		game.placeTile(0, new Location(4,2));
		game.pass();
		game.getBoard().printBoard();
	}
	@Test
	public void testPlace3(){
		Game game = new GameImpl(2);
		game.placeTile(0, new Location(1,2));
		game.placeTile(0, new Location(5,2));
		game.placeTile(0, new Location(2,2));
		game.placeTile(0, new Location(4,2));
		game.getBoard().printBoard();
		game.pass();

		game.placeTile(0, new Location(3,0));

		game.getBoard().printBoard();
		game.placeTile(0, new Location(3,1));
		game.placeTile(0, new Location(3,2));
		game.placeTile(0, new Location(3,3));
		game.placeTile(0, new Location(3,4));
		game.getBoard().printBoard();
		//game.getView().printView();
		game.pass();
		
	}
}
