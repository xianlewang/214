package edu.cmu.cs.cs214.hw4.core;

import static org.junit.Assert.*;

import org.junit.Test;

public class GridTest {

	@Test
	public void testGrid() {
		Grid g = new Grid("DW");
		assertEquals(2,g.getWS());
		assertEquals(1,g.getLS());

	}
	@Test
	public void testGrid2() {
		Grid g = new Grid("TL");
		assertEquals(3,g.getLS());
		assertEquals(1,g.getWS());
	}
	@Test
	public void testGrid3() {
		Grid g = new Grid("TL");
		Tile t = new LetterTile("A",10);
		g.setTile(t);
		assertEquals(10,g.getTile().getScore());
		assertNull(g.getEffect());
		Tile st = new DoubleLetterScoreTile();
		g.setTile(st);
		assertTrue(g.getEffect() instanceof DoubleLetterScoreEffect);
	}
	@Test
	public void testGrid4() {
		Grid g = new Grid("TL");
		Tile t = new LetterTile("A",10);
		g.setTile(t);
		Tile st = new DoubleLetterScoreTile();
		g.setTile(st);
		g.clearScore();
		assertEquals(1,g.getLS());
	}

}
