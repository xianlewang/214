/**
 * hw2 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 15 2013
 */
package edu.cmu.cs.cs214.hw2.actors;

import edu.cmu.cs.cs214.hw2.ai.FoxAI;
import edu.cmu.cs.cs214.hw2.staff.interfaces.Fox;

/**
 * FoxImpl implements the fox
 * 
 * @author xianlewang
 * 
 */
public class FoxImpl extends AnimalBasic implements Fox {
	private static final int FOX_MAX_ENERGY = 160;
	private static final int FOX_VIEW_RANGE = 5;
	private static final int FOX_BREED_LIMIT = FOX_MAX_ENERGY * 3 / 4;
	private static final int FOX_COOL_DOWN = 2;
	private static final int FOX_INITAL_ENERGY = FOX_MAX_ENERGY * 1 / 2;

	/**
	 * Constructor
	 */
	public FoxImpl() {
		remainingEnergy = FOX_INITAL_ENERGY;
		myAI = new FoxAI();
	}

	/**
	 * Constructor
	 */
	public FoxImpl(int energy) {
		remainingEnergy = energy;
		myAI = new FoxAI();
	}

	@Override
	public int getEnergy() {
		return remainingEnergy;
	}

	@Override
	public int getMaxEnergy() {
		return FOX_MAX_ENERGY;
	}

	@Override
	public int getBreedLimit() {
		return FOX_BREED_LIMIT;
	}

	@Override
	public int getViewRange() {
		return FOX_VIEW_RANGE;
	}

	@Override
	public int getCoolDown() {
		return FOX_COOL_DOWN;
	}
}
