/**
 * hw2 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 15 2013
 */
package edu.cmu.cs.cs214.hw2.ai;

import edu.cmu.cs.cs214.hw2.actors.FoxImpl;
import edu.cmu.cs.cs214.hw2.actors.Grass;
import edu.cmu.cs.cs214.hw2.actors.RabbitImpl;
import edu.cmu.cs.cs214.hw2.commands.BreedCommand;
import edu.cmu.cs.cs214.hw2.commands.EatCommand;
import edu.cmu.cs.cs214.hw2.commands.MoveCommand;
import edu.cmu.cs.cs214.hw2.staff.interfaces.AI;
import edu.cmu.cs.cs214.hw2.staff.interfaces.Actor;
import edu.cmu.cs.cs214.hw2.staff.interfaces.Animal;
import edu.cmu.cs.cs214.hw2.staff.interfaces.Command;
import edu.cmu.cs.cs214.hw2.staff.interfaces.World;
import edu.cmu.cs.cs214.hw2.staff.util.Direction;
import edu.cmu.cs.cs214.hw2.staff.util.Location;

/**
 * This class define some common feature of AI class
 * 
 * @author xianlewang
 * 
 */
public abstract class AIBasic implements AI {

	protected Command tryMove(World world, Actor actor, Object[][] things) {
		float desiredDir[] = getDesiredDir(things);
		Direction finalDir = getDir(desiredDir[0], desiredDir[1]);
		return new MoveCommand(finalDir);
	}

	protected float[] getDesiredDir(Object[][] things) {
		float east = 0;
		float south = 0;
		int origin = (things.length - 1) / 2;
		for (int x = 0; x < things.length; ++x) {
			for (int y = 0; y < things.length; ++y) {
				if (x == origin && y == origin)
					continue;
				if (things[x][y] == null)
					continue;
				Object tmpThing = things[x][y];
				float isEast = 0;
				float isSouth = 0;
				if (x != origin)
					isEast = 100 / (x - origin) ^ 3;// how close from east
				if (y != origin)
					isSouth = 100 / (y - origin) ^ 3;// how close from south

				if (tmpThing != null) {
					int importance = getEffactOfAll(tmpThing);
					east += isEast * importance;
					south += isSouth * importance;

				}
			}
		}
		float ans[] = { east, south };
		return ans;
	}

	protected abstract int getEffactOfAll(Object tmpThing);

	protected Command tryBreed(World world, Actor actor) {
		Animal animal = (Animal) actor;
		if (animal.getBreedLimit() > animal.getEnergy())
			return null;
		Location currLoc = world.getLocation(animal);
		for (Direction dir : Direction.values()) {
			Location next = nextLocation(world, dir, currLoc);
			if (next != null) {
				Object nextThing = world.getThing(next);
				if (nextThing == null) {
					return new BreedCommand(dir);
				}
			}
		}
		return null;
	}

	protected Command tryEat(World world, Actor actor) {
		Location currLoc = world.getLocation(actor);
		for (Direction dir : Direction.values()) {
			Location next = nextLocation(world, dir, currLoc);
			if (next != null) {
				Object food = world.getThing(next);
				if (food != null && isPredatorPrey(actor, food)) {
					return new EatCommand(dir);
				}
			}
		}
		return null;
	}

	private boolean isPredatorPrey(Actor actor, Object food) {
		if (actor instanceof RabbitImpl && food instanceof Grass)
			return true;
		else if (actor instanceof FoxImpl && food instanceof RabbitImpl)
			return true;
		else
			return false;

	}

	protected Location nextLocation(World world, Direction dir, Location currLoc) {
		if (dir == null) {
			throw new NullPointerException("Direction must not be null.");
		}
		Location nextLoc = new Location(currLoc, dir);
		if (world.isValidLocation(nextLoc))
			return nextLoc;
		else
			return null;
	}

	protected Object[][] thingsInView(World world, Actor actor) {
		int range = actor.getViewRange();
		int dimension = range * 2 + 1;
		Object things[][] = new Object[dimension][dimension];
		Location currLoc = world.getLocation(actor);
		Location tmp = null;
		int x0 = currLoc.getX();
		int y0 = currLoc.getY();
		for (int x = 0; x < dimension; ++x) {
			for (int y = 0; y < dimension; ++y) {
				tmp = new Location(x0 - range + x, y0 - range + y);
				if (world.isValidLocation(tmp)) {
					Object tmpObj = world.getThing(tmp);
					if (tmpObj != null)
						things[x][y] = (Object) tmpObj;
				}
			}
		}
		return things;
	}

	protected Direction getDir(float east, float south) {
		Direction[] allDirections = Direction.values();
		int dir = (int) (Math.random() * allDirections.length);

		if (east * east > south * south) {
			if (east > 0)
				return Direction.EAST;
			else if (east < 0)
				return Direction.WEST;
			else
				return allDirections[dir];
		} else if (east * east < south * south) {
			if (south > 0)
				return Direction.SOUTH;
			else if (south < 0)
				return Direction.NORTH;
			else
				return allDirections[dir];
		} else {
			return allDirections[dir];
		}
	}

}
