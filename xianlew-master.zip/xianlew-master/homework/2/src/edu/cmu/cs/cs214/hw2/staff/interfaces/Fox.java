package edu.cmu.cs.cs214.hw2.staff.interfaces;

/**
 * A Fox is a non-{@link Edible} {@link Animal}.
 */
public interface Fox extends Animal {
}
