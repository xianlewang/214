/**
 * hw2 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 15 2013
 */
package edu.cmu.cs.cs214.hw2.actors;

import edu.cmu.cs.cs214.hw2.staff.interfaces.AI;
import edu.cmu.cs.cs214.hw2.staff.interfaces.Animal;
import edu.cmu.cs.cs214.hw2.staff.interfaces.Command;
import edu.cmu.cs.cs214.hw2.staff.interfaces.Edible;
import edu.cmu.cs.cs214.hw2.staff.interfaces.World;
import edu.cmu.cs.cs214.hw2.staff.util.Direction;
import edu.cmu.cs.cs214.hw2.staff.util.Location;

/**
 * AnimalBasic class define some common behaviors among animals
 * 
 * @author xianlewang
 * 
 */
public abstract class AnimalBasic implements Animal {
	protected int remainingEnergy;
	protected AI myAI;

	@Override
	public void move(World world, Direction dir) {
		Location nextLoc = nextLocation(world, dir);
		if (nextLoc != null && world.getThing(nextLoc) == null) {
			world.remove(this);
			world.add(this, nextLoc);
		}
	}

	@Override
	public void breed(World world, Direction dir) {
		if (remainingEnergy < getBreedLimit()) {
			return;
		}
		Location nextLoc = nextLocation(world, dir);
		if (nextLoc != null && world.getThing(nextLoc) == null) {
			remainingEnergy /= 2;
			if (this.isRabbit())
				world.add(new RabbitImpl(remainingEnergy), nextLoc);
			else if (this.isFox())
				world.add(new FoxImpl(remainingEnergy), nextLoc);
		}
	}

	@Override
	public void act(World world) {
		if (remainingEnergy <= 0)
			world.remove(this);
		remainingEnergy--;
		Command c = myAI.act(world, this);
		if (c != null) {
			c.execute(world, this);
		} else {
			System.out.println(this + " null decision!!!");
		}
		if (remainingEnergy <= 0)
			world.remove(this);
	}

	protected Location nextLocation(World world, Direction dir) {
		if (world == null) {
			throw new NullPointerException("World must not be null.");
		} else if (dir == null) {
			throw new NullPointerException("Direction must not be null.");
		}
		Location currLoc = world.getLocation(this);
		Location nextLoc = new Location(currLoc, dir);
		if (world.isValidLocation(nextLoc))
			return nextLoc;
		else
			return null;
	}

	@Override
	public void eat(World world, Direction dir) {
		Location nextLoc = nextLocation(world, dir);
		Object foodObj = null;
		if (nextLoc != null) {
			foodObj = world.getThing(nextLoc);
			if (foodObj != null && this.canEat(foodObj)) {
				remainingEnergy += ((Edible) foodObj).getEnergyValue();
				if (remainingEnergy >= getMaxEnergy())
					remainingEnergy = getMaxEnergy();
				world.remove(foodObj);
			}
		}
	}

	protected boolean canEat(Object food) {
		if ((this instanceof RabbitImpl && food instanceof Grass)
				|| (this instanceof FoxImpl && food instanceof RabbitImpl))
			return true;
		else
			return false;
	}

	protected boolean isRabbit() {
		return (this instanceof RabbitImpl);
	}

	protected boolean isFox() {
		return (this instanceof FoxImpl);
	}

}
