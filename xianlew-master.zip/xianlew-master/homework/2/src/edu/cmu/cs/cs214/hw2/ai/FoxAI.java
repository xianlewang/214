/**
 * hw2 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 15 2013
 */
package edu.cmu.cs.cs214.hw2.ai;

import edu.cmu.cs.cs214.hw2.actors.Grass;
import edu.cmu.cs.cs214.hw2.actors.RabbitImpl;
import edu.cmu.cs.cs214.hw2.staff.interfaces.AI;
import edu.cmu.cs.cs214.hw2.staff.interfaces.Actor;
import edu.cmu.cs.cs214.hw2.staff.interfaces.Command;
import edu.cmu.cs.cs214.hw2.staff.interfaces.World;

/**
 * FoxAI implements the AI class for fox
 * 
 * @author xianlewang
 * 
 */
public class FoxAI extends AIBasic implements AI {
	private static final int ATTRACTION_OF_RABBIT = 100;
	private static final int ATTRACTION_OF_GRASS = -50;

	/**
	 * Constructor
	 */
	public FoxAI() {
	}

	@Override
	public Command act(World world, Actor actor) {
		Object things[][] = thingsInView(world, actor);
		Command decision = null;

		decision = tryEat(world, actor);
		if (decision != null) {
			return decision;
		}
		decision = tryBreed(world, actor);
		if (decision != null) {
			return decision;
		}
		decision = tryMove(world, actor, things);
		return decision;
	}

	protected int getEffactOfAll(Object tmpThing) {
		if (tmpThing instanceof RabbitImpl)
			return ATTRACTION_OF_RABBIT;
		if (tmpThing instanceof Grass)
			return ATTRACTION_OF_GRASS;
		return 0;
	}

}
