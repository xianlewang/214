/**
 * hw2 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 15 2013
 */
package edu.cmu.cs.cs214.hw2.commands;

import edu.cmu.cs.cs214.hw2.actors.God;
import edu.cmu.cs.cs214.hw2.staff.interfaces.Actor;
import edu.cmu.cs.cs214.hw2.staff.interfaces.Command;
import edu.cmu.cs.cs214.hw2.staff.interfaces.World;

/**
 * RemoveCommand is used to remove object in the world
 * 
 * @author xianlewang
 * 
 */
public class RemoveCommand implements Command {
	private Object obj;

	/**
	 * Constructor
	 * 
	 * @param obj
	 */
	public RemoveCommand(Object obj) {
		this.obj = obj;
	}

	@Override
	public void execute(World world, Actor actor) {
		if (actor == null) {
			throw new NullPointerException("Actor cannot be null");
		} else if (world == null) {
			throw new NullPointerException("World cannot be null");
		} else if (!(actor instanceof God)) {
			throw new IllegalArgumentException(
					"actor must be an instance of God.");
		}
		try {
			world.remove(obj);
		} catch (IllegalArgumentException except) {
			System.out.println("The object is no longer in the world");
		}

	}

}
