package edu.cmu.cs.cs214.hw2.staff.util;

/**
 * Represents the four directions in the world.
 */
public enum Direction {
	SOUTH, EAST, NORTH, WEST;
}
