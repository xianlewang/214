/**
 * hw2 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 15 2013
 */
package edu.cmu.cs.cs214.hw2.actors;

import edu.cmu.cs.cs214.hw2.ai.RabbitAI;
import edu.cmu.cs.cs214.hw2.staff.interfaces.Rabbit;

/**
 * RabbitImpl implements the rabbit
 * 
 * @author xianlewang
 * 
 */
public class RabbitImpl extends AnimalBasic implements Rabbit {
	private static final int RABBIT_MAX_ENERGY = 20;
	private static final int RABBIT_VIEW_RANGE = 3;
	private static final int RABBIT_BREED_LIMIT = RABBIT_MAX_ENERGY * 3 / 4;
	private static final int RABBIT_ENERGY_VALUE = 20;
	private static final int RABBIT_COOL_DOWN = 4;
	private static final int RABBIT_INITAL_ENERGY = RABBIT_MAX_ENERGY * 1 / 2;

	/**
	 * Constructor
	 */
	public RabbitImpl() {
		remainingEnergy = RABBIT_INITAL_ENERGY;
		myAI = new RabbitAI();
	}

	/**
	 * Constructor
	 * 
	 * @param energy
	 *            the initial energy
	 */
	public RabbitImpl(int energy) {
		remainingEnergy = energy;
		myAI = new RabbitAI();
	}

	@Override
	public int getEnergy() {
		return remainingEnergy;
	}

	@Override
	public int getMaxEnergy() {
		return RABBIT_MAX_ENERGY;
	}

	@Override
	public int getBreedLimit() {
		return RABBIT_BREED_LIMIT;
	}

	@Override
	public int getViewRange() {
		return RABBIT_VIEW_RANGE;
	}

	@Override
	public int getCoolDown() {
		return RABBIT_COOL_DOWN;
	}

	@Override
	public int getEnergyValue() {
		return RABBIT_ENERGY_VALUE;
	}

}
