/**
 * hw2 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 15 2013
 */
package edu.cmu.cs.cs214.hw2.ai;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import edu.cmu.cs.cs214.hw2.actors.FoxImpl;
import edu.cmu.cs.cs214.hw2.actors.RabbitImpl;
import edu.cmu.cs.cs214.hw2.commands.RemoveCommand;
import edu.cmu.cs.cs214.hw2.staff.interfaces.AI;
import edu.cmu.cs.cs214.hw2.staff.interfaces.Actor;
import edu.cmu.cs.cs214.hw2.staff.interfaces.Command;
import edu.cmu.cs.cs214.hw2.staff.interfaces.World;

/**
 * AI of God is used to help God making decision of removing objects in the
 * world
 * 
 * @author xianlewang
 * 
 */
public class GodAI implements AI {

	private static final int UP_LIMIT = 8;
	private static final int DOWN_LIMIT = 4;
	public GodAI() {
	}

	@Override
	public Command act(World world, Actor actor) {

		Object obj = null;
		List<Object> rabbit = new ArrayList<Object>();
		List<Object> fox = new ArrayList<Object>();
		Set<Object> all = world.getAllObjects();
		for (Object thing : all) {
			if (thing instanceof FoxImpl)
				fox.add(thing);
			else if (thing instanceof RabbitImpl)
				rabbit.add(thing);
		}

		if (rabbit.size() / fox.size() > UP_LIMIT)
			obj = rabbit.get(0);
		else if (rabbit.size() / fox.size() < DOWN_LIMIT)
			obj = fox.get(0);
		if (obj != null)
			return new RemoveCommand(obj);
		else
			return null;
	}

}
