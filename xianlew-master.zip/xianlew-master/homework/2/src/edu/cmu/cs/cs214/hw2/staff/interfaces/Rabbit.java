package edu.cmu.cs.cs214.hw2.staff.interfaces;

/**
 * A Rabbit is an {@link Edible} {@link Animal}.
 */
public interface Rabbit extends Animal, Edible {
}
