/**
 * hw2 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 15 2013
 */
package edu.cmu.cs.cs214.hw2.actors;

import edu.cmu.cs.cs214.hw2.ai.GodAI;
import edu.cmu.cs.cs214.hw2.staff.interfaces.Actor;
import edu.cmu.cs.cs214.hw2.staff.interfaces.Command;
import edu.cmu.cs.cs214.hw2.staff.interfaces.World;

/**
 * This creature keep bio-balance of the world
 * 
 * @author xianlewang
 * 
 */
public class God implements Actor {
	private static final int VIEW_RANGE = 1;
	private static final int COOL_DOWN = 0;
	private GodAI myAI;

	/**
	 * Constructor
	 */
	public God() {
		myAI = new GodAI();
	}

	@Override
	public void act(World world) {
		Command c = myAI.act(world, this);
		if (c != null) {
			c.execute(world, this);
		}
	}

	@Override
	public int getViewRange() {
		return VIEW_RANGE;
	}

	@Override
	public int getCoolDown() {
		return COOL_DOWN;
	}

}
