/**
 * hw2 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 15 2013
 */
package edu.cmu.cs.cs214.hw2.ai;

import edu.cmu.cs.cs214.hw2.actors.FoxImpl;
import edu.cmu.cs.cs214.hw2.actors.Grass;
import edu.cmu.cs.cs214.hw2.actors.RabbitImpl;
import edu.cmu.cs.cs214.hw2.commands.MoveCommand;
import edu.cmu.cs.cs214.hw2.staff.interfaces.AI;
import edu.cmu.cs.cs214.hw2.staff.interfaces.Actor;
import edu.cmu.cs.cs214.hw2.staff.interfaces.Command;
import edu.cmu.cs.cs214.hw2.staff.interfaces.World;
import edu.cmu.cs.cs214.hw2.staff.util.Direction;

/**
 * RabbitAI class implements the AI class for rabbit
 * 
 * @author xianlewang
 * 
 */
public class RabbitAI extends AIBasic implements AI {

	private static final int ATTRACTION_OF_RABBIT = -80;
	private static final int ATTRACTION_OF_GRASS = 100;
	private static final int ATTRACTION_OF_FOX = -100;

	/**
	 * Constructor
	 */
	public RabbitAI() {
	}

	@Override
	public Command act(World world, Actor actor) {
		Object things[][] = thingsInView(world, actor);
		Command decision = null;
		decision = tryBreed(world, actor);
		if (decision != null) {
			return decision;
		}
		decision = tryRun(world, actor, things);
		if (decision != null) {
			return decision;
		}
		decision = tryEat(world, actor);
		if (decision != null) {
			return decision;
		}
		decision = tryMove(world, actor, things);
		return decision;
	}

	protected int getEffactOfAll(Object tmpThing) {
		if (tmpThing instanceof RabbitImpl)
			return ATTRACTION_OF_RABBIT;
		if (tmpThing instanceof FoxImpl)
			return ATTRACTION_OF_FOX;
		if (tmpThing instanceof Grass)
			return ATTRACTION_OF_GRASS;
		return 0;
	}

	private Command tryRun(World world, Actor actor, Object[][] things) {
		float east = 0;
		float south = 0;
		int origin = (things.length - 1) / 2;
		int window = origin > 2 ? 2 : origin;
		for (int x = origin - window; x < origin + window + 1; ++x) {
			for (int y = origin - window; y < origin + window + 1; ++y) {
				if (x == origin && y == origin)
					continue;
				if (things[x][y] == null)
					continue;
				Object tmpThing = things[x][y];
				float isEast = 0;
				float isSouth = 0;
				if (x != origin)
					isEast = 1 / (x - origin) ^ 2;// how close from east
				if (y != origin)
					isSouth = 1 / (y - origin) ^ 2;// how close from south

				if (tmpThing != null) {
					if (tmpThing instanceof FoxImpl) {
						east -= isEast * 100;
						south -= isSouth * 100;
					}
				}
			}
		}
		if (east == 0 && south == 0)
			return null;
		else {
			Direction finalDir = getDir(east, south);
			return new MoveCommand(finalDir);
		}
	}

}
