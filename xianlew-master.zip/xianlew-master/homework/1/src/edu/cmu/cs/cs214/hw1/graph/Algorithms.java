/**
 * hw1 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 10 2013
 */
package edu.cmu.cs.cs214.hw1.graph;

import edu.cmu.cs.cs214.hw1.staff.Graph;
import edu.cmu.cs.cs214.hw1.staff.Vertex;

/**
 * Algorithms class
 * 
 * @author xianlewang
 * 
 */
public class Algorithms {

	// *********************** Algorithms ****************************

	/**
	 * This method finds the shortest distance between two vertices. It returns
	 * shortest distance or -1 if the two nodes are not connected.
	 * 
	 * @param graph
	 *            the friends graph
	 * @param a
	 *            the first Giggle+ user
	 * @param b
	 *            the second Giggle+ user
	 */
	public static int shortestDistance(Graph graph, Vertex a, Vertex b) {
		Vertex people[] = graph.getVertices();
		int max = people.length;
		int flag[][] = new int[max][2];// flag: ([visited][distance])
		Queue<Integer> Q = new Queue<Integer>(max);

		int iA = getIndex(people, a);
		int iB = getIndex(people, b);

		flag[iA][0] = 1;
		flag[iA][1] = 0;
		Q.enqueue(iA);

		while (!Q.isEmpty()) {
			int curr = Q.dequeue();
			if (curr == iB) {
				return flag[curr][1];
			}
			for (int friend : getFriends(people,
					graph.getNeighbors(people[curr]))) {
				if (flag[friend][0] == 1)
					continue;
				flag[friend][0] = 1;
				flag[friend][1] = flag[curr][1] + 1;
				Q.enqueue(friend);
			}
		}

		return -1;
	}

	/**
	 * This method is used to find common friends between v1 and v2. This method
	 * should return the vertices in alphabetical order. The result should not
	 * contain any duplicates.
	 * 
	 * @param graph
	 *            the friends graph
	 * @param a
	 *            the first Giggle+ user
	 * @param b
	 *            the second Giggle+ user
	 */
	public static Vertex[] commonFriends(Graph graph, Vertex a, Vertex b) {
		int count = 0;

		Vertex[] all = graph.getVertices();
		Vertex[] common = new Vertex[all.length];
		int flag[] = new int[all.length];

		Vertex[] aFriends = graph.getNeighbors(a);
		Vertex[] bFriends = graph.getNeighbors(b);
		if (aFriends==null||bFriends==null)
			return null;
		for (Vertex friend : aFriends) {
			flag[getIndex(all, friend)] = 1;
		}
		for (Vertex friend : bFriends) {
			if (flag[getIndex(all, friend)] == 1) {
				common[count] = friend;
				++count;
			}
		}
		Vertex ans[] = new Vertex[count];
		System.arraycopy(common, 0, ans, 0, count);
		return sort(ans);
	}

	/**
	 * This method is used to find the person who has the most common friends
	 * with a particular user. Use alphabetical order to break a tie.
	 * 
	 * @param graph
	 *            the friends graph
	 * @param source
	 *            the Giggle+ user in question
	 */
	public static Vertex suggestFriend(Graph graph, Vertex source) {
		Vertex suggest = null;
		int max = 0;
		Vertex tmp[] = sort(graph.getVertices());
		for (Vertex v : tmp) {
			if (!v.equals(source) && !graph.isAdjacent(v, source)&&commonFriends(graph, source, v)!=null) {
				
				int com = commonFriends(graph, source, v).length;
				if (com > max) {
					suggest = v;
					max = com;
				}
			}
		}
		return suggest;
	}

	private static int getIndex(Vertex[] all, Vertex one) {
		for (int i = 0; i < all.length-1; ++i) {
			if (all[i].equals(one))
				return i;
		}
		return all.length;
	}

	private static int[] getFriends(Vertex[] all, Vertex[] v) {
		int friends[] = new int[v.length];
		for (int i = 0; i < friends.length; ++i) {
			friends[i] = getIndex(all, v[i]);
		}
		return friends;
	}

	private static Vertex[] sort(Vertex[] origin) {
		Vertex tmp[] = origin.clone();
		Vertex out;
		for (int i = 0; i < tmp.length; ++i) {
			out = tmp[i];
			for (int j = i; j < tmp.length; ++j) {
				if (tmp[j].getLabel().compareTo(out.getLabel()) < 0) {
					tmp[i] = tmp[j];
					tmp[j] = out;
					out = tmp[i];

				}
			}
		}
		return tmp;
	}
}
