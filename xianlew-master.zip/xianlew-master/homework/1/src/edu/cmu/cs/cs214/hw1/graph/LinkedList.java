/**
 * hw1 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 10 2013
 */
package edu.cmu.cs.cs214.hw1.graph;

/**
 * LinkedList class as a data structure
 * 
 * @author xianlewang
 * 
 */
public class LinkedList {
	private Node head;
	private int nNode;

	/**
	 * Constructor
	 */
	public LinkedList() {
		head = null;
		nNode = 0;
	}

	/**
	 * Add data as a new node at the beginning
	 * 
	 * @param data
	 */
	public void add(int data) {
		head = new Node(data, head);
		++nNode;
	}

	public boolean isEmpty(){
		return nNode==0;
	}
	
	/**
	 * Get all data in the list
	 * 
	 * @return all the data as an array
	 */
	public int[] getAll() {
		int[] all = new int[nNode];
		Node tmp = head;
		for (int i = 0; i < nNode; ++i) {
			all[i] = tmp.data;
			tmp = tmp.next;
		}
		return all;
	}

	private static class Node {
		private int data;
		private Node next;

		/**
		 * Constructor
		 * 
		 * @param data
		 *            the data of the node
		 * @param next
		 *            the next node
		 */
		public Node(int data, Node next) {
			this.data = data;
			this.next = next;
		}
	}

}
