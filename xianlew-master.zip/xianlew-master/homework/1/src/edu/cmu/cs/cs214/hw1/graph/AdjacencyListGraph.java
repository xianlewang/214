/**
 * hw1 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 10 2013
 */
package edu.cmu.cs.cs214.hw1.graph;

import edu.cmu.cs.cs214.hw1.staff.Graph;
import edu.cmu.cs.cs214.hw1.staff.Vertex;

/**
 * AdjacencyListGraph class used to represents friends relationship
 * 
 * @author xianlewang
 * 
 */
public class AdjacencyListGraph implements Graph {
	private Vertex[] all;
	private int nVertex;
	private LinkedList[] edges;

	/**
	 * Constructor
	 * 
	 * @param maxVertices
	 */
	public AdjacencyListGraph(int maxVertices) {
		all = new Vertex[maxVertices];
		nVertex = 0;
		edges = new LinkedList[maxVertices];
	}

	@Override
	public void addVertex(Vertex v) {
		all[nVertex] = v;
		edges[nVertex] = new LinkedList();
		++nVertex;
	}

	@Override
	public void addEdge(Vertex v1, Vertex v2) {
		int n1 = getIndex(v1);
		int n2 = getIndex(v2);
		if (n1 == -1 || n2 == -1) {
			return;
		}
		edges[n1].add(n2);
		edges[n2].add(n1);
	}

	@Override
	public boolean isAdjacent(Vertex v1, Vertex v2) {
		int n1 = getIndex(v1);
		int n2 = getIndex(v2);
		if (n1 == -1 || n2 == -1) {
			return false;
		}
		int[] v1Neighbors = edges[n1].getAll();
		for (int i = 0; i < v1Neighbors.length; ++i) {
			if (v1Neighbors[i] == n2)
				return true;
		} 
		return false;
	}

	@Override
	public Vertex[] getNeighbors(Vertex v) {
		int n = getIndex(v);
		if(n==-1)
			return null;
		if(edges[getIndex(v)].isEmpty())
			return null;
		int[] vNeighbors = edges[getIndex(v)].getAll();
		Vertex[] neighbors = new Vertex[vNeighbors.length];
		for (int i = 0; i < neighbors.length; ++i) {
			neighbors[i] = all[vNeighbors[i]];
		}
		return neighbors;
	}

	@Override
	public Vertex[] getVertices() {
		if(nVertex==0)
			return null;
		Vertex[] tmp = new Vertex[nVertex];
		for (int i = 0; i < nVertex; ++i) {
			tmp[i] = all[i];
		}
		return tmp;
	}

	private int getIndex(Vertex v) {
		for (int i = 0; i < nVertex; ++i) {
			if (all[i].equals(v))
				return i;
		}
		return -1;
	}

}