/**
 * hw1 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 10 2013
 */
package edu.cmu.cs.cs214.hw1.graph;

import edu.cmu.cs.cs214.hw1.staff.Graph;
import edu.cmu.cs.cs214.hw1.staff.Vertex;

/**
 * AdjacencyMatrixGraph class used to represent friendship
 * 
 * @author xianlewang
 * 
 */
public class AdjacencyMatrixGraph implements Graph {

	private Vertex[] all;
	private int nVertex;
	private int[][] edges;// the matrix

	/**
	 * Constructor
	 * 
	 * @param maxVertices
	 */
	public AdjacencyMatrixGraph(int maxVertices) {
		all = new Vertex[maxVertices];
		nVertex = 0;
		edges = new int[maxVertices][maxVertices];
	}

	@Override
	public void addVertex(Vertex v) {
		all[nVertex] = v;
		++nVertex;
	}

	@Override
	public void addEdge(Vertex v1, Vertex v2) {
		int n1 = getIndex(v1);
		int n2 = getIndex(v2);
		if (n1 == -1 || n2 == -1) {
			return;
		}
		edges[n1][n2] = 1;
		edges[n2][n1] = 1;

	}

	@Override
	public boolean isAdjacent(Vertex v1, Vertex v2) {
		int n1 = getIndex(v1);
		int n2 = getIndex(v2);
		if(n1==-1||n2==-1)
			return false;
		if (edges[n1][n2] == 1)
			return true;
		return false;
	}

	@Override
	public Vertex[] getNeighbors(Vertex v) {
		int n = getIndex(v);
		if(n==-1)
			return null;
		int count = 0;
		Vertex[] tmp = new Vertex[nVertex];
		
		for (int i = 0; i < all.length; ++i) {
			if (edges[n][i] == 1) {
				tmp[count] = all[i];
				++count;
			}
		}
		if(count==0)
			return null;
		Vertex[] tmp2 = new Vertex[count];
		System.arraycopy(tmp, 0, tmp2, 0, count);
		return tmp2;
	}

	@Override
	public Vertex[] getVertices() {
		if(nVertex==0)
			return null;
		Vertex[] tmp = new Vertex[nVertex];
		for (int i = 0; i < nVertex; ++i) {
			tmp[i] = all[i];
		}
		return tmp;
	}

	private int getIndex(Vertex v) {
		for (int i = 0; i < nVertex; ++i) {
			if (all[i].equals(v))
				return i;
		}
		return -1;
	}
}
