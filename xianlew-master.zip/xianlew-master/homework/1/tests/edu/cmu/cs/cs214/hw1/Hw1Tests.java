/**
 * hw3 for 15214
 * Name: Xianle Wang
 * Andrew ID: xianlew
 * Date: Sept. 26 2013
 */
package edu.cmu.cs.cs214.hw1;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import edu.cmu.cs.cs214.hw1.graph.AdjacencyListGraph;
import edu.cmu.cs.cs214.hw1.graph.AdjacencyMatrixGraph;
import edu.cmu.cs.cs214.hw1.graph.Algorithms;
import edu.cmu.cs.cs214.hw1.staff.Graph;
import edu.cmu.cs.cs214.hw1.staff.Vertex;

/**
 * @author xianlewang
 * 
 */
public class Hw1Tests {
	private AdjacencyListGraph listG;
	private AdjacencyMatrixGraph matrixG;
	private Vertex a = new Vertex("A");
	private Vertex b = new Vertex("B");
	private Vertex c = new Vertex("C");
	private Vertex d = new Vertex("D");
	private Vertex e = new Vertex("E");
	private Vertex f = new Vertex("F");
	private Vertex g = new Vertex("G");
	private Vertex h = new Vertex("H");
	private Vertex i = new Vertex("I");

	@Before
	public void setup() {
		listG = new AdjacencyListGraph(10);
		matrixG = new AdjacencyMatrixGraph(10);
		setup(listG);
		setup(matrixG);
	}

	private void setup(Graph graph) {
		graph.addVertex(a);
		graph.addVertex(b);
		graph.addVertex(c);
		graph.addVertex(e);
		graph.addVertex(d);
		graph.addVertex(f);
		graph.addVertex(g);
		graph.addVertex(h);
		graph.addVertex(i);

		graph.addEdge(a, b);
		graph.addEdge(a, c);
		graph.addEdge(a, f);
		graph.addEdge(b, e);
		graph.addEdge(b, f);
		graph.addEdge(c, d);
		graph.addEdge(d, e);
		graph.addEdge(g, h);
	}

	@Test
	public void testGraphGetNeighbors() {
		testGraphGetNeighbors(listG);
		testGraphGetNeighbors(matrixG);
	}

	private void testGraphGetNeighbors(Graph graph) {
		assertNull(graph.getNeighbors(i));
		assertNull(graph.getNeighbors(new Vertex("x")));
	}

	/**
	 * Find bug: should return false when send outer vertex into isAdjacent()
	 */
	@Test
	public void testGraphIsAdjacent() {
		testGraphIsAdjacent(listG);
		testGraphIsAdjacent(matrixG);
	}

	private void testGraphIsAdjacent(Graph graph) {
		assertFalse(graph.isAdjacent(i, c));
		assertFalse(graph.isAdjacent(new Vertex("x"), new Vertex("x")));
		assertFalse(graph.isAdjacent(g, new Vertex("x")));
	}

	@Test
	public void testGraphGetVeticles() {
		listG = new AdjacencyListGraph(9);
		matrixG = new AdjacencyMatrixGraph(9);
		testGraphGetVeticles(listG);
		testGraphGetVeticles(matrixG);
	}

	private void testGraphGetVeticles(Graph graph) {
		assertNull(graph.getVertices());
	}

	@Test
	public void testGraphAddEdge() {
		testGraphAddEdge(listG);
		testGraphAddEdge(matrixG);
	}

	private void testGraphAddEdge(Graph graph) {
		graph.addEdge(new Vertex("x"), new Vertex("x"));
		graph.addEdge(g, new Vertex("x"));
	}

	/**
	 * Find bugs: should return null when vertex has no neighbor
	 */
	@Test
	public void testCommonFriends() {
		testCommonFriends(listG);
		testCommonFriends(matrixG);
	}

	private void testCommonFriends(Graph graph) {
		Algorithms algorithms = new Algorithms();
		assertEquals(f, Algorithms.commonFriends(graph, a, b)[0]);
	}

	@Test
	public void testShortestDistance() {
		testShortestDistance(listG);
		testShortestDistance(matrixG);
	}

	private void testShortestDistance(Graph graph) {
		assertEquals(-1, Algorithms.shortestDistance(graph, a, i));
		assertEquals(2, Algorithms.shortestDistance(graph, a, d));
		assertEquals(b, Algorithms.suggestFriend(graph, c));
	}

	@Test
	public void testVertex() {
		Vertex v = new Vertex("a");
		assertEquals("a".hashCode(), v.hashCode());
		assertEquals("a", v.toString());
		assertEquals("a", v.toString());
		assertFalse(v.equals("a"));
		v.setLabel("b");
		assertEquals("b", v.toString());
	}

}
