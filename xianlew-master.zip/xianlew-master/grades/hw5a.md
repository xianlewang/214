hw5a Feedback
=============

### Framework Description (10/10)

 * Great!

---

### Design Model (35/35)

#### Design Structure (15/15)

 * Very nice design. The interactions between classes is very clear and the plug-ins are unable to access the framework internals (such as the GUI, etc.), which is even better. Great!

#### Framework/Plugin Interaction (15/15)

#### Style (5/5)

 * LGTM!

---

### Presentation (30/30)

#### Description of Framework (10/10)

#### Talk Quality (10/10)

 * Very nice presentation!

#### Timing (10/10)

---

### Additional Notes

 * This is the [`RateLimitStatusListener`](http://twitter4j.org/javadoc/twitter4j/RateLimitStatusListener.html) class I was talking about during your presentation. Google search for examples on how to use it... it will make life very easy for you. :)

 * Awesome job, guys. Good luck on milestone B!

---

### Total (75/75)

---

Graded by: Alex Lockwood (alockwoo@andrew.cmu.edu)

To view this file with formatting, visit the following page: https://github.com/CMU-15-214/xianlew/blob/master/grades/hw5a.md
