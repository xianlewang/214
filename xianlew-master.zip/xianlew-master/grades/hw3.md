hw3 Feedback
============

#### `AvlTreeSet` Code Coverage (25/25)

#### `AvlTreeSet` Bug Correction (15/15)

#### `AvlTreeSet` Class Invariants (15/15)

#### HW1 Code Coverage (30/30)

#### Documentation & Style (15/15)

---

#### Total (100/100)

Late days used: 0 (5 left)

---

#### Additional Notes

 * Good job!

Graded by: Shannon Lee (sjl1@andrew.cmu.edu)

To view this file with formatting, visit the following page: https://github.com/CMU-15-214/xianlew/blob/master/grades/hw3.md