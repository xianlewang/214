hw4c Feedback
=============

#### Separation of GUI and Core (20/20)

#### GUI implementation (10/10)

#### Special Tiles (8/10)

 * -2 It is unclear what the effects of the special tiles are (in terms of the GUI).

#### Game Play (10/10)

#### Information Display (10/10)

#### Style (14/15)

 * -1 Magic numbers in GamePanel.java#L133 could be declared as a static final constant at the beginning of the class.

#### Discussion (25/25)

#### Points back for hw4a

3 * 0.75 = 2.25

---

#### Total (97/100)

Late days used: 0 (remaining: 4)

---

#### Additional Notes

Graded by: Daniel Lu (dylu@andrew.cmu.edu)

To view this file with formatting, visit the following page: https://github.com/CMU-15-214/xianlew/blob/master/grades/hw4c.md
