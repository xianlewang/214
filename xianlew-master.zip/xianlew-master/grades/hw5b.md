hw5b Feedback
=============

### Framework Implementation (59/60)

#### Meets requirements (20/20)

 * Perfect!

#### Control flow (20/20)

 * Great, I encountered no errors with your framework. Nice job!

#### Gathered Twitter data (10/10)

#### Framework design (9/10)

 * -1, It is not clear why the `startPullData()` method needs to be `synchronized`. The `synchronized` keyword is used to ensure that only one thread can ever invoke the method at once. However, you only ever call this method from inside an `ActionListener`, and all GUI events in Swing happen on the same thread (called the `EventDispatchThread`), so there is no reason to add extra synchronization here. In the future, if you are ever wondering if you should make something `synchronized`, ask yourself whether or not the method will ever be called from multiple threads in the first place.

 * Awesome job using an `ExecutorService` in your implementation! I'm happy to see that you used it. :)

---

### Sample Plug-ins (20/20)

 * Great!

---

### Documentation (10/10)

 * Some of the best documentation I've seen so far. :)

### Style (9/10)

 * -1, Avoid magic numbers in your code (i.e. like hard coding the value `6` into your code directly [here](https://github.com/CMU-15-214/Team27/blob/master/hw5b/src/edu/cmu/cs/cs214/hw5/framework/FrameworkImpl.java#L213). What does the `6` represent here?).

---

### Additional Notes

 * Very nice job!

---

### Total (including extra credit): (98/100)

---

Graded by: Alex Lockwood (alockwoo@andrew.cmu.edu)

To view this file with formatting, visit the following page: https://github.com/CMU-15-214/xianlew/blob/master/grades/hw5b.md
