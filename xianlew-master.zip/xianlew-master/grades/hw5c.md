hw5c Feedback
=============

### Experience Report (10/10)

---

### Plugin Implementation (50/50)

### Style (14/15)

* -1, Please remove commented out code, your submissions should be finalized

---

### Additional Notes

---

### Total: (74/75)

---

Graded by: Mathew Gray (mhgray@andrew.cmu.edu)

To view this file with formatting, visit the following page: https://github.com/CMU-15-214/xianlew/blob/master/grades/hw5c.md
