hw2 Feedback
============

#### Correct working Rabbit and Fox implementations with working AIs (50/50)

#### Completion of Third Animal(8/10)
+ -2 Sometimes `God` would cause divide by zero error
    - Not even `God` can divide by zero! (but Chuck Norris...)

#### Design (25/30)
+ -5 Incorrect use of instanceof
    - `AbstractAnimal#canEat` should be overridden in each Animal type
    - `AbstractAnimal#isRabbit` and `isFox` shouldn't exist. See piazza post
    337 on how to properly handle breeding (Factory Method)
    - The problem of how you are using `instaceof` is that it doesn't scale
    and is hard to maintain. Imagine if you had to add 10 new animals, you
    would need to add an `isAnimalType` method for each type of Animal

#### Documentation and Style (10/10)

---

#### Total (93/100)

Late days used: 0 (5 left)

---

#### Additional Notes

Graded by: bcforres

To view this file with formatting, visit the following page: https://github.com/CMU-15-214/ANDREW-ID-HERE/blob/master/grades/hw2.md
