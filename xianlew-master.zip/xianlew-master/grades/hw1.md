hw1 Feedback
============

#### Correct Graph Implementations (35/35)

* -0.1, You should use a `boolean[][]` array instead of an `int[][]` array to represent your adjacency matrix since each entry represents a "yes" or "no" decision.

* -0.1, Using `clone()` like [this](https://github.com/CMU-15-214/xianlew/blob/master/homework/1/src/edu/cmu/cs/cs214/hw1/graph/Algorithms.java#L141) will not have the intended affects because the `Vertex` class does not implement `Cloneable`! You should just create a new `Vertex` object using its constructor instead of calling `clone()`.

#### Correct Algorithm Implementations (40/40)

#### Good Style and Program Design (13/15)

* -1, Variable names should start with lowercase letters ([link](https://github.com/CMU-15-214/xianlew/blob/master/homework/1/src/edu/cmu/cs/cs214/hw1/graph/Algorithms.java#L37)).

* -1, Variable names should not be in all caps like [this](https://github.com/CMU-15-214/xianlew/blob/master/homework/1/src/edu/cmu/cs/cs214/hw1/graph/Queue.java#L27).


#### At Least Three Additional Test Cases (5/5)

#### Free points for Javadocs (5/5)

---

#### Total 98/100)

Late days used: 0 (5 left)

---

#### Additional Notes

* Great job!

Graded by: Alex Lockwood (alockwoo)

To view this file with formatting, visit the following page: https://github.com/CMU-15-214/xianlew/blob/master/grades/hw1.md