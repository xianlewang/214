hw4a Feedback
============

**IMPORTANT:** If we ask any questions about your design, briefly respond to them in a file called `{your repo}/homework/4/response.pdf`. This will count as part of your Milestone B grade!

#### Questions from the TA
 
#### Design Model (29/30)

 * -1 Some methods such as purchase() in Game should take in paramters instead of nothing.

#### Rationale (8/10)

 * -2 Rationale needs to provide reason why the design given is best.

#### Interfaces and Class Stubs (10/10)

---

#### Total (47/50)

Late days used: 0 (5 left)

---

#### Additional Notes

Graded by: Danny Lu (dylu@andrew.cmu.edu)

To view this file with formatting, visit the following page: https://github.com/CMU-15-214/xianlew/blob/master/grades/hw4a.md
