hw6 Feedback
============

#### `AbstractClient` Implementation (5/5)

* Good

#### `WorkerServer` Implementation (5/5)

* Good

#### `MasterServer` Implementation (10/10)

* Good

#### Map/Shuffle/Reduce Phases (20/20)

* Good

#### Correctness (10/10)

* Good

#### Robustness (10/10)

* Good job!

#### `WordPrefixMapTask` Implementation (10/10)

* Good

#### `WordPrefixReduceTask` Implementation (10/10)

* Good

#### Documentation & Style (10/10)

* Good

#### FindBugs Extra Credit

 * 0 points (12 bug(s) found)

--- 

#### Total score, including extra credit: (90/90)

Late days used: 2 (2 left)

---

#### Additional Notes

 * Please consider leaving feedback for your TA this semester! We would really appreciate it! Thanks!

 * TA feedback (by Dec 19): https://www.ugrad.cs.cmu.edu/ta/F13/feedback

---

Graded by: Mathew Gray (mhgray@andrew.cmu.edu)

To view this file with formatting, visit the following page: https://github.com/CMU-15-214/xianlew/blob/master/grades/hw6.md
