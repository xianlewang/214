hw0 Feedback
============

#### Submitting a compiling solution (20/20)

#### Working `getDistance` implementation (10/10)

 * Great job!

#### Fulfilling technical requirements (10/10)

#### Documentation and code style (8/10)

 * -1, you should make [these fields](https://github.com/CMU-15-214/xianlew/blob/master/homework/0/src/hw0/Person.java#L16-L18) `private` instead of `public` and access them with methods. This is important because you want to *encapsulate* data in Java so that your classes are more modular (see [slide 13 of the 'Encapsulation and Inheritance` lecture](http://www.cs.cmu.edu/~charlie/courses/15-214/2013-fall/slides/03%20Encapsulation%20and%20inheritance.pdf#)).

 * -1, instead of [single-character variable names](https://github.com/CMU-15-214/xianlew/blob/master/homework/0/src/hw0/Queue.java#L22), please use names that are more descriptive. This makes your code easier to read (and to grade).

 * -0.1, instead of using [`return n <= 0 ? true : false;`](https://github.com/CMU-15-214/xianlew/blob/master/homework/0/src/hw0/Queue.java#L68), you can instead write:

  ```java
    public boolean isEmpty() {
        return n <= 0;
    }
  ```

  This does the same thing and is more clear :).

 * -0.1, you should have named the [`wasVst` field in Person] (https://github.com/CMU-15-214/xianlew/blob/master/homework/0/src/hw0/Person.java#L16) something like `wasVisited` since it is more clear. I was pretty confused at first.

 * This wasn't taught in lecture yet, but instead of [comparing strings with `==`](https://github.com/CMU-15-214/xianlew/blob/master/homework/0/src/hw0/FriendGraph.java#L122), use the `.equals()` method instead; it's safer because it compares the attributes of the `Object` instead of checking if they are the same reference.

---

#### Total (48/50)

Late days used: 0 (5 left)

---

#### Additional Notes

 * Pretty good :).

Graded by: Shannon Lee (sjl1)

To view this file with formatting, visit the following page: https://github.com/CMU-15-214/xianlew/blob/master/grades/hw0.md
