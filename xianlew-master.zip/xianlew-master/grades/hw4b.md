hw4b Feedback
============

#### Response to questions from TA (25/25)

#### Implementation of core game features (50/50)

 * Board (5/5)

 * Player (10/10)

 * Game Flow (25/25)

 * "Stuff" Implementation (10/10)

#### Tests for the core implementation (15/15)

#### Javadoc comments and style (10/10)

---

#### Total (100/100)

Late days used: 1 (4 remaining)

---

#### Additional Notes

Graded by: Daniel Lu (dylu@andrew.cmu.edu)

To view this file with formatting, visit the following page: https://github.com/CMU-15-214/xianlew/blob/master/grades/hw4b.md
